// Virelio's mark: concentric arcs like a lens iris opening — the signature
// element. Built as inline SVG so no external asset pipeline is needed.
export function Logo({ size = 28 }: { size?: number }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10 }}>
      <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
        <circle cx="16" cy="16" r="14" stroke="#332a3d" strokeWidth="2" />
        <path d="M16 4a12 12 0 0 1 12 12" stroke="#f2a65a" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M16 9a7 7 0 0 1 7 7" stroke="#8b7fd1" strokeWidth="2.5" strokeLinecap="round" />
        <circle cx="16" cy="16" r="2.5" fill="#f2a65a" />
      </svg>
      <span className="font-display font-bold tracking-tight text-[19px] text-ink">
        Virelio <span className="text-muted font-medium">AI</span>
      </span>
    </span>
  );
}
