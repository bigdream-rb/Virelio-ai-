const OPTIONS = ['16:9', '9:16', '1:1'] as const;

export function AspectSelector({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <div className="flex gap-2">
      {OPTIONS.map((o) => (
        <button key={o} type="button" onClick={() => onChange(o)}
          className={`px-4 py-2.5 rounded-xl2 border text-sm font-mono transition-colors ${
            value === o ? 'border-gold bg-gold/10 text-ink' : 'border-line text-muted hover:text-ink'
          }`}>
          {o}
        </button>
      ))}
    </div>
  );
}
