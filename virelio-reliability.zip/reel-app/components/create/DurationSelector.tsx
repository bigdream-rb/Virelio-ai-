const OPTIONS = [
  { value: 15, label: '15 sec', supported: true },
  { value: 30, label: '30 sec', supported: true },
  { value: 60, label: '1 min', supported: true },
  { value: 180, label: '3 min', supported: true },
  { value: 300, label: '5 min', supported: true },
  { value: 600, label: '10 min', supported: true },
  { value: 900, label: '15 min', supported: true },
  { value: 1800, label: '30 min', supported: true },
];

export function DurationSelector({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  return (
    <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
      {OPTIONS.map((o) => (
        <button key={o.value} type="button" disabled={!o.supported}
          onClick={() => onChange(o.value)}
          className={`relative px-3 py-3 rounded-xl2 border text-sm font-medium transition-colors ${
            !o.supported ? 'border-line text-muted/50 cursor-not-allowed' :
            value === o.value ? 'border-gold bg-gold/10 text-ink' : 'border-line text-muted hover:text-ink'
          }`}>
          {o.label}
          {!o.supported && <span className="block text-[10px] font-mono mt-0.5">coming soon</span>}
        </button>
      ))}
    </div>
  );
}
