// UI-only for now — same reasoning as VoiceSelector.
const MOODS = ['Cinematic','Emotional','Action','Horror','Happy','Sad','Adventure','Calm'];

export function MusicSelector({ value, onChange }: { value: string | null; onChange: (v: string) => void }) {
  return (
    <div>
      <div className="flex flex-wrap gap-2">
        {MOODS.map((m) => (
          <button key={m} type="button" onClick={() => onChange(m)}
            className={`px-3 py-1.5 rounded-full border text-xs font-mono transition-colors ${
              value === m ? 'border-gold bg-gold/10 text-ink' : 'border-line text-muted hover:text-ink'
            }`}>
            {m}
          </button>
        ))}
      </div>
      <p className="text-xs text-muted mt-2">Sets the mood tag now; real generated tracks arrive once MusicProvider is wired in.</p>
    </div>
  );
}
