// UI-only for now — real voices arrive once VoiceProvider is wired to
// ElevenLabs (Step 5+). Shown so the layout is real, previews are not.
export function VoiceSelector() {
  const voices = ['Narrator — warm', 'Narrator — energetic', 'Character — young', 'Character — deep'];
  return (
    <div>
      <div className="grid grid-cols-2 gap-2">
        {voices.map((v) => (
          <div key={v} className="flex items-center justify-between px-4 py-3 rounded-xl2 border border-line text-muted text-sm">
            {v}
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-surface2">preview soon</span>
          </div>
        ))}
      </div>
      <p className="text-xs text-muted mt-2">Voice generation connects in a later step — this is the picker UI only.</p>
    </div>
  );
}
