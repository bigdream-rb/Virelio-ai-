const STYLES = [
  { value: 'realistic', label: 'Realistic' },
  { value: 'cinematic', label: 'Cinematic' },
  { value: '3d_animation', label: '3D Animation' },
  { value: 'cartoon', label: 'Cartoon' },
  { value: 'anime', label: 'Anime' },
];

export function StyleSelector({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
      {STYLES.map((s) => (
        <button key={s.value} type="button" onClick={() => onChange(s.value)}
          className={`px-4 py-3 rounded-xl2 border text-sm font-medium text-left transition-colors ${
            value === s.value ? 'border-gold bg-gold/10 text-ink' : 'border-line text-muted hover:text-ink'
          }`}>
          {s.label}
        </button>
      ))}
    </div>
  );
}
