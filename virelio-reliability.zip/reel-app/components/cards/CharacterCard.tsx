export function CharacterCard({ character, onDelete }: {
  character: { id: string; name: string; age?: string | null; gender?: string | null; appearance?: string | null };
  onDelete: (id: string) => void;
}) {
  return (
    <div className="bg-surface border border-line rounded-xl2 p-4">
      <div className="w-full aspect-square rounded-xl2 bg-surface2 mb-3 flex items-center justify-center text-muted text-xs font-mono">
        no reference image yet
      </div>
      <p className="font-display font-semibold">{character.name}</p>
      <p className="text-xs text-muted mt-1">{[character.age, character.gender].filter(Boolean).join(' · ') || '—'}</p>
      {character.appearance && <p className="text-xs text-muted mt-2 line-clamp-2">{character.appearance}</p>}
      <button onClick={() => onDelete(character.id)} className="text-xs text-bad mt-3">Delete</button>
    </div>
  );
}
