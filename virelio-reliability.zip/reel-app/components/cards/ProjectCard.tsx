import Link from 'next/link';

const STATUS_STYLE: Record<string, string> = {
  draft: 'text-muted bg-surface2',
  generating: 'text-gold bg-gold/10',
  complete: 'text-good bg-good/10',
  failed: 'text-bad bg-bad/10',
};

export function ProjectCard({ project }: { project: {
  id: string; title: string | null; prompt: string; style: string;
  duration_seconds: number; status: string; created_at: string;
} }) {
  return (
    <Link href={`/projects/${project.id}`}
      className="block bg-surface border border-line rounded-xl2 overflow-hidden hover:border-gold/50 transition-colors">
      <div className="aspect-video bg-surface2 flex items-center justify-center text-muted text-xs font-mono">
        no preview yet
      </div>
      <div className="p-4">
        <p className="font-display font-semibold truncate">{project.title || project.prompt}</p>
        <div className="flex items-center gap-2 mt-2 text-xs text-muted font-mono">
          <span>{project.style}</span>
          <span>·</span>
          <span>{project.duration_seconds}s</span>
        </div>
        <div className="flex items-center justify-between mt-3">
          <span className={`text-[11px] font-mono px-2 py-0.5 rounded-full ${STATUS_STYLE[project.status] ?? ''}`}>
            {project.status}
          </span>
          <span className="text-[11px] text-muted">{new Date(project.created_at).toLocaleDateString()}</span>
        </div>
      </div>
    </Link>
  );
}
