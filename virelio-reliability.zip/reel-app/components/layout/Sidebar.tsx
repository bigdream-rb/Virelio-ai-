'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Logo } from '@/components/brand/Logo';

const NAV = [
  { href: '/dashboard', label: 'Dashboard' },
  { href: '/create', label: 'Create Video' },
  { href: '/projects', label: 'Projects' },
  { href: '/characters', label: 'Characters' },
  { href: '/settings', label: 'Settings' },
];

export function Sidebar() {
  const pathname = usePathname();
  return (
    <aside className="hidden md:flex md:flex-col w-60 shrink-0 border-r border-line px-5 py-6">
      <div className="mb-10"><Logo /></div>
      <nav className="space-y-1">
        {NAV.map((item) => {
          const active = pathname.startsWith(item.href);
          return (
            <Link key={item.href} href={item.href}
              className={`block px-3 py-2 rounded-xl2 text-sm font-medium transition-colors ${
                active ? 'bg-surface text-ink' : 'text-muted hover:text-ink hover:bg-surface'
              }`}>
              {item.label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
