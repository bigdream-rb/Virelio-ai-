'use client';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

export function Header({ email, credits }: { email?: string; credits?: number }) {
  const router = useRouter();
  const supabase = createClient();

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push('/login');
    router.refresh();
  }

  return (
    <header className="flex items-center justify-between px-6 py-4 border-b border-line">
      <div className="md:hidden font-display font-bold">Virelio <span className="text-muted font-medium">AI</span></div>
      <div className="hidden md:block" />
      <div className="flex items-center gap-4">
        <div className="font-mono text-xs bg-surface border border-line rounded-full px-3 py-1.5 text-gold">
          {typeof credits === 'number' ? `${credits} credits` : '—'}
        </div>
        <span className="text-sm text-muted hidden sm:inline">{email}</span>
        <button onClick={handleLogout} className="text-sm text-muted hover:text-ink">Log out</button>
      </div>
    </header>
  );
}
