'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const NAV = [
  { href: '/dashboard', label: 'Home' },
  { href: '/create', label: 'Create' },
  { href: '/projects', label: 'Projects' },
  { href: '/characters', label: 'Cast' },
  { href: '/settings', label: 'Settings' },
];

export function MobileNav() {
  const pathname = usePathname();
  return (
    <nav className="md:hidden fixed bottom-0 inset-x-0 border-t border-line bg-base/95 backdrop-blur flex justify-around py-2 z-40">
      {NAV.map((item) => {
        const active = pathname.startsWith(item.href);
        return (
          <Link key={item.href} href={item.href}
            className={`flex flex-col items-center gap-1 px-3 py-1 text-[11px] font-mono ${
              active ? 'text-gold' : 'text-muted'
            }`}>
            <span className={`w-1.5 h-1.5 rounded-full ${active ? 'bg-gold' : 'bg-transparent'}`} />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}
