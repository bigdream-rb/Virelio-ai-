import { Sidebar } from './Sidebar';
import { MobileNav } from './MobileNav';
import { Header } from './Header';

export function AppShell({
  children, email, credits,
}: { children: React.ReactNode; email?: string; credits?: number }) {
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Header email={email} credits={credits} />
        <main className="flex-1 px-6 py-6 pb-24 md:pb-6">{children}</main>
      </div>
      <MobileNav />
    </div>
  );
}
