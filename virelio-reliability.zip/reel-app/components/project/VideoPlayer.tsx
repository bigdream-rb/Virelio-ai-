import { EmptyState } from '@/components/ui/EmptyState';

export function VideoPlayer({ url }: { url: string | null }) {
  if (!url) {
    return (
      <EmptyState
        title="No video yet"
        body="The final render will appear here once generation completes."
      />
    );
  }
  return (
    <div className="rounded-xl2 overflow-hidden border border-line bg-black">
      <video src={url} controls className="w-full aspect-video" />
      <div className="flex gap-3 p-3 border-t border-line">
        <a href={url} download className="text-sm text-gold font-medium">Download</a>
        <button onClick={() => navigator.clipboard.writeText(url)} className="text-sm text-muted">Copy link</button>
      </div>
    </div>
  );
}
