// Renders real generation_jobs rows — nothing simulated. Rewritten
// (Step 13 fix): the old version used jobs.find() per stage, which only
// ever saw the FIRST job of a type. For scene_video/voice/sfx there are
// many job rows per type (one per scene), so it could never actually
// show "12 of 40" — it just showed whichever single row it happened to
// find. Also replaced the fixed 7-step percentage (which reads a
// 250-scene project as "1/7 done" right after script generation) with a
// percentage computed from real job counts.
type Job = { job_type: string; status: string };

const STAGE_ORDER = ['script', 'character_image', 'scene_video', 'voice', 'music', 'sfx', 'assemble'];
const STAGE_LABELS: Record<string, string> = {
  script: 'Writing script',
  character_image: 'Generating character references',
  scene_video: 'Generating scenes',
  voice: 'Generating narration',
  music: 'Generating music',
  sfx: 'Adding sound effects',
  assemble: 'Rendering final video',
};

export function GenerationProgress({ jobs }: { jobs: Job[] }) {
  const byType = (t: string) => jobs.filter((j) => j.job_type === t);
  const totalJobs = jobs.length;
  const succeededJobs = jobs.filter((j) => j.status === 'succeeded').length;
  const pct = totalJobs > 0 ? Math.round((succeededJobs / totalJobs) * 100) : 0;

  return (
    <div className="bg-surface border border-line rounded-xl2 p-5">
      <div className="flex items-center justify-between mb-4">
        <p className="font-display font-semibold text-sm">Generation progress</p>
        <span className="font-mono text-xs text-muted">{pct}%</span>
      </div>
      <div className="h-1.5 bg-surface2 rounded-full mb-5 overflow-hidden">
        <div className="h-full bg-gold transition-all" style={{ width: `${pct}%` }} />
      </div>
      <ul className="space-y-2.5">
        {STAGE_ORDER.map((type, i) => {
          const stageJobs = byType(type);
          const total = stageJobs.length;

          if (total === 0) {
            // Either "hasn't started yet" or "legitimately skipped" (e.g. a
            // project with no extracted characters has zero character_image
            // jobs). Distinguish by checking whether a LATER stage already
            // has jobs — if so, this one was skipped, not just pending, and
            // showing it stuck at "pending" forever would be misleading.
            const laterHasJobs = STAGE_ORDER.slice(i + 1).some((t) => byType(t).length > 0);
            if (laterHasJobs) return null;
            return (
              <li key={type} className="flex items-center gap-2.5 text-sm text-muted">
                <span className="font-mono w-4">○</span>{STAGE_LABELS[type]}
              </li>
            );
          }

          const succeeded = stageJobs.filter((j) => j.status === 'succeeded').length;
          const failed = stageJobs.filter((j) => j.status === 'failed').length;
          const allDone = succeeded === total;
          const icon = allDone ? '✓' : failed > 0 ? '✕' : '●';
          const color = allDone ? 'text-good' : failed > 0 ? 'text-bad' : 'text-gold';
          // "Scene 27 of 150" style — only shown when there's more than
          // one job in this stage, so single-job stages like script/music
          // don't get a redundant "1/1".
          const countSuffix = total > 1 ? ` — ${succeeded} of ${total}` : '';
          const failedSuffix = failed > 0 ? ` (${failed} failed)` : '';

          return (
            <li key={type} className={`flex items-center gap-2.5 text-sm ${color}`}>
              <span className="font-mono w-4">{icon}</span>{STAGE_LABELS[type]}{countSuffix}{failedSuffix}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
