export function EmptyState({
  title, body, action,
}: { title: string; body?: string; action?: React.ReactNode }) {
  return (
    <div className="border border-dashed border-line rounded-xl2 py-12 px-6 text-center">
      <p className="font-display font-semibold text-ink mb-1">{title}</p>
      {body && <p className="text-muted text-sm max-w-sm mx-auto mb-4">{body}</p>}
      {action}
    </div>
  );
}
