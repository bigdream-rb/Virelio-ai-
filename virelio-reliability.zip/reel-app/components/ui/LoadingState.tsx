export function LoadingState({ label = 'Loading…' }: { label?: string }) {
  return (
    <div className="flex items-center gap-3 text-muted text-sm py-8 justify-center">
      <span className="w-2 h-2 rounded-full bg-gold animate-pulse" />
      {label}
    </div>
  );
}
