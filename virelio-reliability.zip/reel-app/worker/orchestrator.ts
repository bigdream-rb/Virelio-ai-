// The queue itself: polls generation_jobs for queued rows and dispatches
// by job_type. Advances a project through script -> scenes -> voice ->
// music -> sfx -> assemble by creating the next stage's job rows once
// the current stage's jobs all succeed. Untested against a live Supabase
// project — correct against the schema, unverified end-to-end.
import { createServiceClient } from '../lib/supabase/server';
import { runGenerateScriptJob } from './jobs/generate-script';
import { runGenerateCharacterImageJob } from './jobs/generate-character-image';
import { runGenerateSceneVideoJob } from './jobs/generate-scene-video';
import { runGenerateVoiceJob } from './jobs/generate-voice';
import { runGenerateMusicJob } from './jobs/generate-music';
import { runGenerateSFXJob } from './jobs/generate-sfx';
import { runCompleteProjectJob } from './jobs/complete-project';

const HANDLERS: Record<string, (jobId: string) => Promise<void>> = {
  script: runGenerateScriptJob,
  character_image: runGenerateCharacterImageJob,
  scene_video: runGenerateSceneVideoJob,
  voice: runGenerateVoiceJob,
  music: runGenerateMusicJob,
  sfx: runGenerateSFXJob,
  assemble: runCompleteProjectJob,
};

async function advanceProjectIfReady(projectId: string) {
  const supabase = createServiceClient();
  const { data: project } = await supabase.from('projects').select('status').eq('id', projectId).single();
  if (!project || project.status === 'cancelled' || project.status === 'failed') return; // don't advance a dead project

  const { data: jobs } = await supabase.from('generation_jobs').select('*').eq('project_id', projectId);
  if (!jobs) return;

  const byType = (t: string) => jobs.filter((j) => j.job_type === t);
  const notStarted = (t: string) => byType(t).length === 0;
  const succeededAll = (t: string) => byType(t).length > 0 && byType(t).every((j) => j.status === 'succeeded');

  // Sequential, one stage transition per call, always returning right
  // after creating the next stage's jobs. This matters: reading all job
  // statuses once at the top of the function and then making several
  // "if stage X is done, start stage Y" decisions off that same stale
  // snapshot would let a later stage's jobs get created before an
  // earlier stage's jobs even exist in the DB. Early-returning after
  // each transition means the *next* poll always re-reads fresh state.

  if (!succeededAll('script')) return; // nothing to advance until script succeeds

  if (notStarted('character_image')) {
    const { data: characters } = await supabase.from('characters').select('id').eq('project_id', projectId).is('reference_image_url', null);
    if ((characters ?? []).length > 0) {
      for (const c of characters!) {
        await supabase.from('generation_jobs').upsert(
        { project_id: projectId, character_id: c.id, job_type: 'character_image', status: 'queued' },
        { onConflict: 'project_id,character_id,job_type', ignoreDuplicates: true }
      );
      }
      return; // wait for these before touching scenes
    }
    // no characters need images — fall through to scene_video below
  } else if (!succeededAll('character_image')) {
    return; // still in progress
  }

  if (notStarted('scene_video')) {
    const { data: scenes } = await supabase.from('scenes').select('id').eq('project_id', projectId).order('scene_index');
    for (const s of scenes ?? []) {
      await supabase.from('generation_jobs').upsert(
        { project_id: projectId, scene_id: s.id, job_type: 'scene_video', status: 'queued' },
        { onConflict: 'project_id,scene_id,job_type', ignoreDuplicates: true }
      );
    }
    return;
  }
  if (!succeededAll('scene_video')) return;

  if (notStarted('voice')) {
    const { data: scenes } = await supabase.from('scenes').select('id').eq('project_id', projectId).order('scene_index');
    for (const s of scenes ?? []) {
      await supabase.from('generation_jobs').upsert(
        { project_id: projectId, scene_id: s.id, job_type: 'voice', status: 'queued' },
        { onConflict: 'project_id,scene_id,job_type', ignoreDuplicates: true }
      );
    }
    return;
  }
  if (!succeededAll('voice')) return;

  if (notStarted('music')) {
    await supabase.from('generation_jobs').upsert(
      { project_id: projectId, job_type: 'music', status: 'queued' },
      { onConflict: 'project_id,job_type', ignoreDuplicates: true }
    );
    return;
  }
  if (!succeededAll('music')) return;

  if (notStarted('sfx')) {
    const { data: scenes } = await supabase.from('scenes').select('id').eq('project_id', projectId).order('scene_index');
    for (const s of scenes ?? []) {
      await supabase.from('generation_jobs').upsert(
        { project_id: projectId, scene_id: s.id, job_type: 'sfx', status: 'queued' },
        { onConflict: 'project_id,scene_id,job_type', ignoreDuplicates: true }
      );
    }
    return;
  }
  if (!succeededAll('sfx')) return;

  if (notStarted('assemble')) {
    await supabase.from('generation_jobs').upsert(
      { project_id: projectId, job_type: 'assemble', status: 'queued' },
      { onConflict: 'project_id,job_type', ignoreDuplicates: true }
    );
  }
}

export async function pollOnce() {
  const supabase = createServiceClient();

  // Requirement #21: recover jobs a crashed/killed worker left stuck in
  // "running" — without this, a dead worker permanently wedges the project.
  const { data: reaped } = await supabase.rpc('reap_stuck_jobs', { p_timeout_minutes: 10, p_max_attempts: 5 });
  if (reaped) console.log(`[virelio-worker] reaped ${reaped} stuck job(s)`);

  const { data: claimed, error } = await supabase.rpc('claim_generation_jobs', { p_batch_size: 5 });
  if (error) { console.error('[virelio-worker] claim failed', error); return; }
  for (const job of claimed ?? []) {
    const handler = HANDLERS[job.job_type];
    if (!handler) continue;
    console.log(`[virelio-worker] processing ${job.job_type} job ${job.id}`);
    await handler(job.id);
    await advanceProjectIfReady(job.project_id);
  }
}

export async function startWorkerLoop(intervalMs = 3000) {
  // eslint-disable-next-line no-constant-condition
  while (true) {
    try { await pollOnce(); } catch (err) { console.error('worker poll error', err); }
    await new Promise((r) => setTimeout(r, intervalMs));
  }
}
