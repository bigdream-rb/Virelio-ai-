// Fixes audit finding #2 — the orchestrator existed but nothing actually
// started it. This is the real, standalone entry point: `npm run worker`.
// Never run inside a Next.js request — this is a long-lived process.
import { pollOnce } from './orchestrator';

let shuttingDown = false;

async function loop() {
  console.log(`[worker] started at ${new Date().toISOString()}`);
  while (!shuttingDown) {
    try {
      await pollOnce();
    } catch (err) {
      console.error('[worker] poll error:', err);
    }
    await new Promise((r) => setTimeout(r, 3000));
  }
  console.log('[worker] stopped cleanly');
}

process.on('SIGTERM', () => { console.log('[worker] SIGTERM received, shutting down...'); shuttingDown = true; });
process.on('SIGINT', () => { console.log('[worker] SIGINT received, shutting down...'); shuttingDown = true; });
process.on('uncaughtException', (err) => console.error('[worker] uncaught exception:', err));
process.on('unhandledRejection', (err) => console.error('[worker] unhandled rejection:', err));

loop();
