// Shared failure handling for every job type — Step 14 fix. Two real
// gaps closed here:
// 1. A transient error (network blip, provider rate limit) used to
//    permanently fail a job on the very first attempt — there was no
//    retry path except the stuck-in-"running" reaper, which only helps
//    a crashed worker, not a job that ran and got a real error back.
// 2. Several job handlers never told the PROJECT it had failed, so a
//    permanently-failed voice/music/sfx/character-image job left the
//    project silently stuck at "generating" forever — advanceProjectIfReady
//    requires ALL jobs of a stage to succeed and had no escape hatch.
import { createServiceClient } from '../../lib/supabase/server';

const MAX_ATTEMPTS = 3;

export async function handleJobFailure(
  supabase: ReturnType<typeof createServiceClient>,
  job: { id: string; project_id: string; attempt_count: number },
  err: unknown
): Promise<boolean> {
  const nextAttempt = (job.attempt_count ?? 0) + 1;
  const message = err instanceof Error ? err.message : String(err);

  if (nextAttempt < MAX_ATTEMPTS) {
    // Transient — requeue for another try. Credits already charged for
    // this job (if any) stay charged; charge functions are keyed by job
    // id and are no-ops on a repeat call, so the retry won't double-charge.
    await supabase.from('generation_jobs').update({
      status: 'queued', error_message: message, attempt_count: nextAttempt,
    }).eq('id', job.id);
    return false;
  }

  // Exhausted retries — permanent failure. Refund whatever was charged
  // for this specific job, and make sure the PROJECT reflects it instead
  // of sitting at "generating" forever with no way for the user to know.
  await supabase.rpc('refund_credits_for_job', { p_job_id: job.id });
  await supabase.from('generation_jobs').update({
    status: 'failed', error_message: message, attempt_count: nextAttempt,
  }).eq('id', job.id);
  await supabase.from('projects').update({ status: 'failed' }).eq('id', job.project_id);
  return true;
}
