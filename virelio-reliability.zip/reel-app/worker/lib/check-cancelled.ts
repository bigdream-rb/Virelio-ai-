// Step 3 reliability fix: only generate-script.ts checked for a
// cancelled project before doing work. Every other job type would
// charge credits and call a real (paid) provider even after the user
// cancelled — a job that was already claimed and running had no way to
// notice cancellation happened underneath it. Every job now checks this
// right before charging/calling a provider, not just at job start,
// since cancellation can happen at any moment while a job is in flight.
import { createServiceClient } from '../../lib/supabase/server';

export async function bailIfCancelled(
  supabase: ReturnType<typeof createServiceClient>,
  projectId: string,
  jobId: string
): Promise<boolean> {
  const { data: project } = await supabase.from('projects').select('status').eq('id', projectId).single();
  if (project?.status === 'cancelled') {
    await supabase.from('generation_jobs').update({ status: 'cancelled' }).eq('id', jobId);
    return true;
  }
  return false;
}
