// Stage 10, project-level (one track for the whole video). Phase 11 fix:
// was defaulting to project.style because music_mood wasn't persisted —
// migration 0003 added the column, and the Create Video page now saves
// the user's actual selection, so this uses the real value.
import { createServiceClient } from '../../lib/supabase/server';
import { handleJobFailure } from '../lib/job-failure';
import { bailIfCancelled } from '../lib/check-cancelled';
import { musicProvider } from '../../lib/providers';

export async function runGenerateMusicJob(jobId: string) {
  const supabase = createServiceClient();
  const { data: job } = await supabase.from('generation_jobs').select('*').eq('id', jobId).single();
  if (!job) throw new Error(`job ${jobId} not found`);
  if (await bailIfCancelled(supabase, job.project_id, jobId)) return;

  const { data: project } = await supabase.from('projects').select('*').eq('id', job.project_id).single();
  if (!project) return;

  try {
    const { data: charged } = await supabase.rpc('charge_credits_for_job', { p_job_id: jobId, p_amount: 1 });
    if (!charged) throw new Error('insufficient credits');

    const mood = project.music_mood || project.style; // fallback only if user never picked one
    const { audioUrl } = await musicProvider.generateMusic({ mood, durationSeconds: project.duration_seconds });
    await supabase.from('assets').insert({ project_id: project.id, type: 'music', url: audioUrl, provider: 'music' });
    await supabase.from('generation_jobs').update({ status: 'succeeded' }).eq('id', jobId);
  } catch (err: any) {
    await handleJobFailure(supabase, job, err);
  }
}
