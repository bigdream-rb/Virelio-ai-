// Stage 9, per-scene. Skips scenes with no narration/dialogue text.
// Fix: was not charging credits at all, and never passed the project's
// selected voice — always used ElevenLabs' default voice regardless of
// what the user picked.
import { createServiceClient } from '../../lib/supabase/server';
import { handleJobFailure } from '../lib/job-failure';
import { bailIfCancelled } from '../lib/check-cancelled';
import { voiceProvider } from '../../lib/providers';

const COST = 1;

export async function runGenerateVoiceJob(jobId: string) {
  const supabase = createServiceClient();
  const { data: job } = await supabase.from('generation_jobs').select('*').eq('id', jobId).single();
  if (!job || !job.scene_id) throw new Error(`job ${jobId} missing scene_id`);
  if (await bailIfCancelled(supabase, job.project_id, jobId)) return;
  const { data: scene } = await supabase.from('scenes').select('*').eq('id', job.scene_id).single();
  const { data: project } = await supabase.from('projects').select('voice_id').eq('id', job.project_id).single();
  if (!scene) return;

  const text = scene.narration_text || scene.dialogue;
  if (!text) {
    await supabase.from('generation_jobs').update({ status: 'succeeded' }).eq('id', jobId); // nothing to narrate — not a failure
    return;
  }

  try {
    const { data: charged } = await supabase.rpc('charge_credits_for_job', { p_job_id: jobId, p_amount: COST });
    if (!charged) throw new Error('insufficient credits');

    const { audioUrl } = await voiceProvider.synthesizeNarration({ text, voiceId: project?.voice_id ?? undefined });
    await supabase.from('scenes').update({ audio_url: audioUrl }).eq('id', scene.id);
    await supabase.from('assets').insert({ project_id: job.project_id, scene_id: scene.id, type: 'audio', url: audioUrl, provider: 'voice' });
    await supabase.from('generation_jobs').update({ status: 'succeeded' }).eq('id', jobId);
  } catch (err: any) {
    await handleJobFailure(supabase, job, err);
  }
}
