// Step 3 reliability fix: the long-video path is now genuinely resumable.
// Previously, any failure partway through the batched-beat loop meant
// permanent failure — retrying would re-call generateOutline (possibly
// getting a DIFFERENT outline) and re-insert scenes at scene_index values
// that already existed, hitting the unique constraint. Now:
//   - The outline is persisted to projects.script_outline on first
//     success, and reused on retry instead of being regenerated.
//   - projects.script_beats_completed checkpoints how many beats have
//     had their scenes successfully inserted; a retry skips straight to
//     the first incomplete beat.
// The short-video path (<=60s) doesn't need this: it's a single call
// that either fully succeeds or inserts nothing, so it was already safe
// to retry as-is.
import { createServiceClient } from '../../lib/supabase/server';
import { handleJobFailure } from '../lib/job-failure';
import { llmProvider } from '../../lib/providers';

const SCRIPT_GENERATION_COST = 1;
const SHORT_VIDEO_THRESHOLD = 60;

export async function runGenerateScriptJob(jobId: string) {
  const supabase = createServiceClient();
  const { data: job } = await supabase.from('generation_jobs').select('*').eq('id', jobId).single();
  if (!job) throw new Error(`job ${jobId} not found`);

  const { data: project } = await supabase.from('projects').select('*').eq('id', job.project_id).single();
  if (!project) {
    await supabase.from('generation_jobs').update({ status: 'failed', error_message: 'project not found' }).eq('id', jobId);
    return;
  }
  if (project.status === 'cancelled') {
    await supabase.from('generation_jobs').update({ status: 'cancelled' }).eq('id', jobId);
    return;
  }

  try {
    // Idempotent: charge_credits_for_job is a no-op on repeat calls for
    // the same job id, so resuming after a partial failure never double-charges.
    const { data: charged, error: chargeErr } = await supabase.rpc('charge_credits_for_job', { p_job_id: jobId, p_amount: SCRIPT_GENERATION_COST });
    if (chargeErr) throw new Error(`credit charge failed: ${chargeErr.message}`);
    if (!charged) {
      await supabase.from('generation_jobs').update({ status: 'failed', error_message: 'insufficient credits' }).eq('id', jobId);
      await supabase.from('projects').update({ status: 'failed' }).eq('id', project.id);
      return;
    }
    if (!project.generation_started_at) {
      await supabase.from('projects').update({ generation_started_at: new Date().toISOString() }).eq('id', project.id);
    }

    let title: string;

    if (project.duration_seconds <= SHORT_VIDEO_THRESHOLD) {
      const script = await llmProvider.generateScript({ prompt: project.prompt, style: project.style, totalDurationSeconds: project.duration_seconds });
      title = script.title;
      await insertScenes(supabase, project.id, script.scenes, 0);
    } else {
      // Reuse the persisted outline on resume instead of calling the LLM
      // again — a second generateOutline call could plausibly return a
      // different story/character set, which would corrupt any scenes
      // already inserted under the first outline's characters.
      let outline = project.script_outline as {
        title: string; summary: string;
        characters: { name: string; description: string }[];
        beats: { summary: string; approxDurationSeconds: number }[];
      } | null;

      if (!outline) {
        outline = await llmProvider.generateOutline({ prompt: project.prompt, style: project.style, totalDurationSeconds: project.duration_seconds });
        await supabase.from('projects').update({ script_outline: outline }).eq('id', project.id);
      }
      title = outline.title;

      // Character rows: safe to just ensure-exists on every call (keyed
      // by name+user), whether this is a first run or a resume.
      const { data: existingChars } = await supabase.from('characters').select('id, name').eq('user_id', project.user_id);
      const charIdByName = new Map((existingChars ?? []).map((c) => [c.name, c.id]));
      for (const c of outline.characters) {
        if (!charIdByName.has(c.name)) {
          const { data: created } = await supabase.from('characters').insert({
            user_id: project.user_id, project_id: project.id, name: c.name, appearance: c.description,
          }).select('id').single();
          if (created) charIdByName.set(c.name, created.id);
        }
      }

      // Resume point: how many scenes already exist (= next scene_index
      // to use) and which beat to start from (checkpointed after each
      // beat's scenes are successfully inserted).
      const { count: existingSceneCount } = await supabase.from('scenes').select('id', { count: 'exact', head: true }).eq('project_id', project.id);
      let nextIndex = existingSceneCount ?? 0;

      for (let beatIndex = project.script_beats_completed; beatIndex < outline.beats.length; beatIndex++) {
        const beat = outline.beats[beatIndex];
        const batch = await llmProvider.generateSceneBatch({
          title: outline.title, summary: outline.summary, characters: outline.characters, beat, style: project.style, startIndex: nextIndex,
        });
        await insertScenes(supabase, project.id, batch, nextIndex, charIdByName);
        nextIndex += batch.length;
        await supabase.from('projects').update({ script_beats_completed: beatIndex + 1 }).eq('id', project.id);
      }
    }

    await supabase.from('projects').update({ title, status: 'generating' }).eq('id', project.id);
    await supabase.from('generation_jobs').update({ status: 'succeeded' }).eq('id', jobId);
  } catch (err: any) {
    // Now safe to auto-retry: resuming re-reads script_outline and
    // script_beats_completed from the DB, so it picks up exactly where
    // the failed attempt left off instead of restarting or duplicating.
    await handleJobFailure(supabase, job, err);
  }
}

async function insertScenes(supabase: any, projectId: string, scenes: any[], indexOffset: number, charIdByName?: Map<string, string>) {
  for (const s of scenes) {
    const { data: inserted } = await supabase.from('scenes').insert({
      project_id: projectId,
      scene_index: indexOffset + (s.index ?? 0),
      description: s.description,
      location: s.location ?? null,
      camera_movement: s.cameraMovement ?? null,
      dialogue: s.dialogue ?? null,
      narration_text: s.narrationText ?? null,
      duration_seconds: s.durationSeconds,
      status: 'pending',
    }).select('id').single();

    if (inserted && charIdByName && s.characterNames?.length) {
      const links = s.characterNames
        .filter((n: string) => charIdByName.has(n))
        .map((n: string) => ({ scene_id: inserted.id, character_id: charIdByName.get(n) }));
      if (links.length > 0) await supabase.from('scene_characters').insert(links);
    }
  }
}
