// Redesigned for hundreds of scenes (a 30-minute video at ~7s/scene is
// ~250 scenes). The old version built one filter_complex covering every
// scene's narration at once — fine for 3 scenes, a real problem at 250
// (command-line size, memory, and one failure invalidating the whole
// render). Now processes scenes in fixed-size batches, muxing each
// batch's video+local-audio into a small segment file, then concatenates
// segments (stream copy, cheap) and overlays the full-length music once
// at the end — that overlay is always a fixed 2-input mix regardless of
// scene count, so it doesn't scale with project length either.
//
// Also fixes a real bug from the original version (see Step 3 report):
// `amix duration=first` + `-shortest` truncated the whole video to the
// first narration clip's length. And a second real gap: SFX used to be
// one flat list mixed at t=0 for everything, with no per-scene timeline
// position — fixed by pairing each SFX to its scene like narration.
import { spawn } from 'child_process';
import { writeFile, mkdtemp, rm } from 'fs/promises';
import { tmpdir } from 'os';
import path from 'path';

const BATCH_SIZE = 20; // scenes per intermediate segment

function run(cmd: string, args: string[]): Promise<void> {
  return new Promise((resolve, reject) => {
    const p = spawn(cmd, args);
    let stderr = '';
    p.stderr.on('data', (d) => (stderr += d));
    p.on('close', (code) => (code === 0 ? resolve() : reject(new Error(`${cmd} exited ${code}: ${stderr.slice(-2000)}`))));
  });
}

function probeDuration(file: string): Promise<number> {
  return new Promise((resolve, reject) => {
    const p = spawn('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'default=nw=1:nk=1', file]);
    let out = '';
    p.stdout.on('data', (d) => (out += d));
    p.on('close', (code) => (code === 0 ? resolve(parseFloat(out.trim())) : reject(new Error('ffprobe failed'))));
  });
}

async function buildAudioMixForBatch(
  dir: string, batchIndex: number, narrationPaths: (string | null)[], sfxPaths: (string | null)[],
  sceneDurations: number[], batchTotalDuration: number
): Promise<string | null> {
  let offset = 0;
  const parts: { path: string; delayMs: number; volume: number }[] = [];
  for (let i = 0; i < sceneDurations.length; i++) {
    if (narrationPaths[i]) parts.push({ path: narrationPaths[i]!, delayMs: Math.round(offset * 1000), volume: 1.0 });
    if (sfxPaths[i]) parts.push({ path: sfxPaths[i]!, delayMs: Math.round(offset * 1000), volume: 0.8 });
    offset += sceneDurations[i];
  }
  if (parts.length === 0) return null;

  const out = path.join(dir, `batch-audio-${batchIndex}.m4a`);
  const args = ['-y'];
  parts.forEach((p) => args.push('-i', p.path));
  const labels = parts.map((p, i) => `[${i}:a]aformat=channel_layouts=stereo,adelay=${p.delayMs}:all=1,volume=${p.volume},apad,atrim=0:${batchTotalDuration}[a${i}]`).join(';');
  const mixInputs = parts.map((_, i) => `[a${i}]`).join('');
  args.push('-filter_complex', `${labels};${mixInputs}amix=inputs=${parts.length}:duration=longest:dropout_transition=0[aout]`,
    '-map', '[aout]', '-t', String(batchTotalDuration), '-c:a', 'aac', out);
  await run('ffmpeg', args);
  return out;
}

export async function assembleVideo(input: {
  sceneVideoPaths: string[];
  sceneDurationsSeconds: number[];
  narrationPaths: (string | null)[];
  sfxPaths: (string | null)[]; // one slot per scene, same order — NOT a flat unrelated list anymore
  musicPath: string | null;
  aspectRatio: '16:9' | '9:16' | '1:1';
  outputPath: string;
}): Promise<{ outputPath: string; thumbnailPath: string; totalDuration: number }> {
  const dir = await mkdtemp(path.join(tmpdir(), 'virelio-assemble-'));
  const dims = input.aspectRatio === '16:9' ? '1280:720' : input.aspectRatio === '9:16' ? '720:1280' : '1080:1080';

  const segmentPaths: string[] = [];
  const n = input.sceneVideoPaths.length;

  for (let batchStart = 0; batchStart < n; batchStart += BATCH_SIZE) {
    const batchEnd = Math.min(batchStart + BATCH_SIZE, n);
    const batchIndex = batchStart / BATCH_SIZE;

    // Normalize + concat just this batch's scene clips.
    const normalized: string[] = [];
    for (let i = batchStart; i < batchEnd; i++) {
      const out = path.join(dir, `norm-${i}.mp4`);
      await run('ffmpeg', ['-y', '-i', input.sceneVideoPaths[i],
        '-vf', `scale=${dims}:force_original_aspect_ratio=decrease,pad=${dims}:(ow-iw)/2:(oh-ih)/2,fps=30`,
        '-c:v', 'libx264', '-preset', 'veryfast', '-an', out]);
      normalized.push(out);
    }
    const concatList = path.join(dir, `concat-${batchIndex}.txt`);
    await writeFile(concatList, normalized.map((p) => `file '${p}'`).join('\n'));
    const batchVideo = path.join(dir, `batch-video-${batchIndex}.mp4`);
    await run('ffmpeg', ['-y', '-f', 'concat', '-safe', '0', '-i', concatList, '-c', 'copy', batchVideo]);
    const batchDuration = input.sceneDurationsSeconds.slice(batchStart, batchEnd).reduce((a, b) => a + b, 0);

    const batchAudio = await buildAudioMixForBatch(
      dir, batchIndex,
      input.narrationPaths.slice(batchStart, batchEnd),
      input.sfxPaths.slice(batchStart, batchEnd),
      input.sceneDurationsSeconds.slice(batchStart, batchEnd),
      batchDuration
    );

    const segment = path.join(dir, `segment-${batchIndex}.mp4`);
    if (batchAudio) {
      await run('ffmpeg', ['-y', '-i', batchVideo, '-i', batchAudio, '-map', '0:v', '-map', '1:a', '-c:v', 'copy', '-c:a', 'aac', '-shortest', segment]);
    } else {
      // No narration/SFX in this batch — give it silent audio so every
      // segment has an audio stream (concat demuxer requires matching
      // stream layouts across segments).
      await run('ffmpeg', ['-y', '-i', batchVideo, '-f', 'lavfi', '-i', `anullsrc=r=44100:cl=stereo`, '-map', '0:v', '-map', '1:a', '-c:v', 'copy', '-c:a', 'aac', '-t', String(batchDuration), segment]);
    }
    segmentPaths.push(segment);

    // Clean up this batch's intermediates immediately rather than
    // holding every batch's normalized clips until the very end —
    // requirement #26, avoid accumulating everything in memory/disk.
    await Promise.all(normalized.map((f) => rm(f, { force: true })));
  }

  const segConcatList = path.join(dir, 'segments.txt');
  await writeFile(segConcatList, segmentPaths.map((p) => `file '${p}'`).join('\n'));
  const concatenatedAll = path.join(dir, 'concatenated-all.mp4');
  await run('ffmpeg', ['-y', '-f', 'concat', '-safe', '0', '-i', segConcatList, '-c', 'copy', concatenatedAll]);
  const totalDuration = await probeDuration(concatenatedAll);

  let finalPath = concatenatedAll;
  if (input.musicPath) {
    // Requirement #14: loop the (short) generated music bed to cover the
    // full duration rather than asking the provider for an absurd
    // single-shot length, with a short fade-out so the loop point at the
    // very end doesn't cut off abruptly.
    const loopedMusic = path.join(dir, 'music-looped.m4a');
    await run('ffmpeg', ['-y', '-stream_loop', '-1', '-i', input.musicPath,
      '-t', String(totalDuration), '-af', `volume=0.3,afade=t=out:st=${Math.max(0, totalDuration - 2)}:d=2`, '-c:a', 'aac', loopedMusic]);

    finalPath = input.outputPath;
    await run('ffmpeg', ['-y', '-i', concatenatedAll, '-i', loopedMusic,
      '-filter_complex', '[0:a][1:a]amix=inputs=2:duration=first[aout]',
      '-map', '0:v', '-map', '[aout]', '-t', String(totalDuration), '-c:v', 'copy', '-c:a', 'aac', input.outputPath]);
  } else {
    await run('ffmpeg', ['-y', '-i', concatenatedAll, '-c', 'copy', input.outputPath]);
    finalPath = input.outputPath;
  }

  const thumbnailPath = input.outputPath.replace(/\.mp4$/, '-thumb.jpg');
  await run('ffmpeg', ['-y', '-i', finalPath, '-ss', '00:00:00.5', '-vframes', '1', thumbnailPath]);

  await rm(dir, { recursive: true, force: true });
  return { outputPath: input.outputPath, thumbnailPath, totalDuration };
}
