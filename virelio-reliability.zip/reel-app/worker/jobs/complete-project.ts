// Stage 14, final step. Downloads every generated asset locally, runs
// the tested assembleVideo(), uploads the result to Supabase Storage,
// and marks the project complete. This is the one job whose core logic
// (assembleVideo) was actually verified — see the Step 3 report.
import { createServiceClient } from '../../lib/supabase/server';
import { downloadToTemp } from '../../lib/storage/download';
import { bailIfCancelled } from '../lib/check-cancelled';
import { assembleVideo } from './assemble-video';
import path from 'path';

export async function runCompleteProjectJob(jobId: string) {
  const supabase = createServiceClient();
  const { data: job } = await supabase.from('generation_jobs').select('*').eq('id', jobId).single();
  if (!job) throw new Error(`job ${jobId} not found`);
  if (await bailIfCancelled(supabase, job.project_id, jobId)) return;
  const { data: project } = await supabase.from('projects').select('*').eq('id', job.project_id).single();
  const { data: scenes } = await supabase.from('scenes').select('*').eq('project_id', job.project_id).order('scene_index');
  const { data: musicAsset } = await supabase.from('assets').select('*').eq('project_id', job.project_id).eq('type', 'music').maybeSingle();
  if (!project || !scenes) return;

  const incomplete = scenes.filter((s) => s.status !== 'complete');
  if (incomplete.length > 0) {
    await supabase.from('generation_jobs').update({
      status: 'failed', error_message: `${incomplete.length} scene(s) not yet complete: ${incomplete.map((s) => s.scene_index).join(', ')}`,
    }).eq('id', jobId);
    return;
  }

  try {
    const sceneVideoPaths: string[] = [];
    const narrationPaths: (string | null)[] = [];
    for (const s of scenes) {
      sceneVideoPaths.push(await downloadToTemp(s.video_url, `scene-${s.id}.mp4`));
      narrationPaths.push(s.audio_url ? await downloadToTemp(s.audio_url, `narration-${s.id}.mp3`) : null);
    }
    const musicPath = musicAsset ? await downloadToTemp(musicAsset.url, `music-${project.id}.mp3`) : null;

    // SFX are per-scene assets now (assets.scene_id), not a flat list —
    // needed so assembleVideo can place each one at its scene's actual
    // timeline position instead of dumping them all at t=0.
    const { data: sfxAssets } = await supabase.from('assets').select('*').eq('project_id', project.id).eq('type', 'sfx');
    const sfxByScene = new Map((sfxAssets ?? []).map((a) => [a.scene_id, a]));
    const sfxPaths: (string | null)[] = [];
    for (const s of scenes) {
      const asset = sfxByScene.get(s.id);
      sfxPaths.push(asset ? await downloadToTemp(asset.url, `sfx-${asset.id}.mp3`) : null);
    }

    const outputPath = path.join('/tmp', `final-${project.id}.mp4`);
    const { thumbnailPath, totalDuration } = await assembleVideo({
      sceneVideoPaths,
      sceneDurationsSeconds: scenes.map((s) => s.duration_seconds),
      narrationPaths,
      sfxPaths,
      musicPath,
      aspectRatio: project.aspect_ratio,
      outputPath,
    });

    const fs = await import('fs/promises');
    const videoBuf = await fs.readFile(outputPath);
    const thumbBuf = await fs.readFile(thumbnailPath);
    const videoPath = `users/${project.user_id}/projects/${project.id}/final/output.mp4`;
    const thumbPath = `users/${project.user_id}/projects/${project.id}/thumbnails/thumb.jpg`;

    await supabase.storage.from('assets').upload(videoPath, videoBuf, { contentType: 'video/mp4', upsert: true });
    await supabase.storage.from('assets').upload(thumbPath, thumbBuf, { contentType: 'image/jpeg', upsert: true });
    const { data: videoUrlData } = supabase.storage.from('assets').getPublicUrl(videoPath);

    const dims = project.aspect_ratio === '16:9' ? { width: 1280, height: 720 } : project.aspect_ratio === '9:16' ? { width: 720, height: 1280 } : { width: 1080, height: 1080 };
    await supabase.from('projects').update({
      status: 'complete',
      final_video_url: videoUrlData.publicUrl,
      generation_completed_at: new Date().toISOString(),
      final_video_metadata: { duration_seconds: totalDuration, ...dims, format: 'mp4', file_size_bytes: videoBuf.length },
    }).eq('id', project.id);
    await supabase.from('assets').insert({ project_id: project.id, type: 'final', url: videoUrlData.publicUrl, provider: 'ffmpeg' });
    await supabase.from('generation_jobs').update({ status: 'succeeded' }).eq('id', jobId);
  } catch (err: any) {
    await supabase.from('projects').update({ status: 'failed' }).eq('id', project.id);
    await supabase.from('generation_jobs').update({
      status: 'failed', error_message: String(err.message ?? err), attempt_count: (job.attempt_count ?? 0) + 1,
    }).eq('id', jobId);
  }
}
