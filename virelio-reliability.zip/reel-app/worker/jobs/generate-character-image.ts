// New pipeline stage (requirement #9): one reference image per character,
// generated once and reused across every scene that character appears
// in — never regenerated per-scene. This is what makes requirement #8
// (visual consistency) possible at all with today's providers; it's a
// real limitation, not a guarantee — flagged in the Step report.
import { createServiceClient } from '../../lib/supabase/server';
import { handleJobFailure } from '../lib/job-failure';
import { bailIfCancelled } from '../lib/check-cancelled';
import { imageProvider } from '../../lib/providers';

const COST = 1;

export async function runGenerateCharacterImageJob(jobId: string) {
  const supabase = createServiceClient();
  const { data: job } = await supabase.from('generation_jobs').select('*').eq('id', jobId).single();
  if (!job || !job.character_id) throw new Error(`job ${jobId} missing character_id`);
  if (await bailIfCancelled(supabase, job.project_id, jobId)) return;

  const { data: character } = await supabase.from('characters').select('*').eq('id', job.character_id).single();
  if (!character) return;
  if (character.reference_image_url) {
    // Already has one (reused across projects) — nothing to do, not a failure.
    await supabase.from('generation_jobs').update({ status: 'succeeded' }).eq('id', jobId);
    return;
  }

  try {
    const { data: charged } = await supabase.rpc('charge_credits_for_job', { p_job_id: jobId, p_amount: COST });
    if (!charged) throw new Error('insufficient credits');

    const description = [character.appearance, character.clothing, character.age, character.gender].filter(Boolean).join(', ') || character.name;
    const { imageUrl } = await imageProvider.generateReferenceImage({ description });

    await supabase.from('characters').update({ reference_image_url: imageUrl }).eq('id', character.id);
    await supabase.from('assets').insert({ project_id: job.project_id, type: 'image', url: imageUrl, provider: 'image' });
    await supabase.from('generation_jobs').update({ status: 'succeeded' }).eq('id', jobId);
  } catch (err: any) {
    await handleJobFailure(supabase, job, err);
  }
}
