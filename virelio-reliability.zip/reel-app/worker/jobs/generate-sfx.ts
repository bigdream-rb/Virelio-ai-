// Stage 11, per-scene. Deliberately simple for this pass: uses the scene
// description directly as the SFX prompt rather than a smarter
// keyword-to-effect matcher. Real "automatically pick footsteps vs rain
// vs explosion" logic is a reasonable next improvement, not built here.
// Fix: was never charging credits at all — every SFX generation was free.
import { createServiceClient } from '../../lib/supabase/server';
import { handleJobFailure } from '../lib/job-failure';
import { bailIfCancelled } from '../lib/check-cancelled';
import { sfxProvider } from '../../lib/providers';

export async function runGenerateSFXJob(jobId: string) {
  const supabase = createServiceClient();
  const { data: job } = await supabase.from('generation_jobs').select('*').eq('id', jobId).single();
  if (!job || !job.scene_id) throw new Error(`job ${jobId} missing scene_id`);
  if (await bailIfCancelled(supabase, job.project_id, jobId)) return;
  const { data: scene } = await supabase.from('scenes').select('*').eq('id', job.scene_id).single();
  if (!scene) return;

  try {
    const { data: charged } = await supabase.rpc('charge_credits_for_job', { p_job_id: jobId, p_amount: 1 });
    if (!charged) throw new Error('insufficient credits');

    const { audioUrl } = await sfxProvider.generateSFX({ description: scene.description, durationSeconds: Math.min(scene.duration_seconds, 10) });
    await supabase.from('assets').insert({ project_id: job.project_id, scene_id: scene.id, type: 'sfx', url: audioUrl, provider: 'sfx' });
    await supabase.from('generation_jobs').update({ status: 'succeeded' }).eq('id', jobId);
  } catch (err: any) {
    await handleJobFailure(supabase, job, err);
  }
}
