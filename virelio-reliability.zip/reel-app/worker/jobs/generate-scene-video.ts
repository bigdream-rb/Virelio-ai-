// Stage 8, per-scene. Same credit-charging fix as generate-script.
// Retrying this job retries only this one scene — keyed by scene_id.
import { createServiceClient } from '../../lib/supabase/server';
import { handleJobFailure } from '../lib/job-failure';
import { bailIfCancelled } from '../lib/check-cancelled';
import { videoProvider } from '../../lib/providers';

const COST_PER_SCENE = 2;

export async function runGenerateSceneVideoJob(jobId: string) {
  const supabase = createServiceClient();
  const { data: job } = await supabase.from('generation_jobs').select('*').eq('id', jobId).single();
  if (!job || !job.scene_id) throw new Error(`job ${jobId} missing scene_id`);
  if (await bailIfCancelled(supabase, job.project_id, jobId)) return;

  await supabase.from('scenes').update({ status: 'generating' }).eq('id', job.scene_id);
  const { data: scene } = await supabase.from('scenes').select('*').eq('id', job.scene_id).single();
  const { data: project } = await supabase.from('projects').select('*').eq('id', job.project_id).single();
  if (!scene || !project) return;

  try {
    const { data: charged, error: chargeErr } = await supabase.rpc('charge_credits_for_job', {
      p_job_id: jobId, p_amount: COST_PER_SCENE,
    });
    if (chargeErr) throw new Error(`credit charge failed: ${chargeErr.message}`);
    if (!charged) throw new Error('insufficient credits');

    // Requirement #11: reuse the character's one reference image rather
    // than regenerating identity per scene. Only the first linked
    // character's image is passed — most current video providers accept
    // a single reference image per request, so a second/third character
    // in the same scene falls back to text description only. Real
    // limitation, not hidden.
    const { data: links } = await supabase.from('scene_characters').select('character_id').eq('scene_id', scene.id).limit(1);
    let referenceImageUrl: string | undefined;
    if (links && links.length > 0) {
      const { data: character } = await supabase.from('characters').select('reference_image_url').eq('id', links[0].character_id).single();
      referenceImageUrl = character?.reference_image_url ?? undefined;
    }

    const structuredPrompt = [
      scene.description,
      scene.location && `Location: ${scene.location}.`,
      scene.camera_movement && `Camera: ${scene.camera_movement}.`,
      `Style: ${project.style}, cinematic lighting, coherent atmosphere.`,
    ].filter(Boolean).join(' ');

    const { videoUrl } = await videoProvider.generateSceneVideo({
      prompt: structuredPrompt,
      style: project.style,
      aspectRatio: project.aspect_ratio,
      durationSeconds: scene.duration_seconds,
      characterReferenceImageUrl: referenceImageUrl,
    });

    await supabase.from('scenes').update({ status: 'complete', video_url: videoUrl }).eq('id', scene.id);
    await supabase.from('assets').insert({ project_id: project.id, scene_id: scene.id, type: 'video', url: videoUrl, provider: 'video' });
    await supabase.from('generation_jobs').update({ status: 'succeeded' }).eq('id', jobId);
  } catch (err: any) {
    const permanent = await handleJobFailure(supabase, job, err);
    // Only mark the scene itself failed once retries are exhausted — if
    // this is going to be retried automatically, the scene should go
    // back to "pending" so the UI doesn't show a false permanent failure
    // for what might succeed on the next attempt.
    await supabase.from('scenes').update({ status: permanent ? 'failed' : 'pending' }).eq('id', job.scene_id);
  }
}
