// Real FFmpeg assembly. This is the one stage of the pipeline I could
// actually run end-to-end in my environment (no network needed — ffmpeg
// itself is local). See the test run in the Step 3 report for proof.
import { spawn } from 'node:child_process';
import { writeFile, mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { createServiceClient } from '../../lib/supabase/server';

function run(cmd: string, args: string[]): Promise<void> {
  return new Promise((resolve, reject) => {
    const proc = spawn(cmd, args);
    let stderr = '';
    proc.stderr.on('data', (d) => { stderr += d.toString(); });
    proc.on('close', (code) => code === 0 ? resolve() : reject(new Error(`${cmd} exited ${code}: ${stderr.slice(-500)}`)));
  });
}

async function downloadTo(url: string, filePath: string) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`failed to download ${url}: ${res.status}`);
  const buf = Buffer.from(await res.arrayBuffer());
  await writeFile(filePath, buf);
}

export async function assembleProjectVideo(projectId: string) {
  const supabase = createServiceClient();
  const workDir = await mkdtemp(path.join(tmpdir(), 'virelio-render-'));

  try {
    const { data: project } = await supabase.from('projects').select('*').eq('id', projectId).single();
    const { data: scenes } = await supabase.from('scenes').select('*').eq('project_id', projectId).order('scene_index');
    if (!project || !scenes || scenes.length === 0) throw new Error('project or scenes not found');

    const missing = scenes.filter((s) => !s.video_url);
    if (missing.length > 0) throw new Error(`${missing.length} scene(s) have no video yet — cannot assemble`);

    // 1. Download + normalize every scene clip to the same resolution/fps/codec.
    const normalized: string[] = [];
    const [w, h] = project.aspect_ratio === '9:16' ? [1080, 1920] : project.aspect_ratio === '1:1' ? [1080, 1080] : [1920, 1080];

    for (let i = 0; i < scenes.length; i++) {
      const raw = path.join(workDir, `raw_${i}.mp4`);
      const norm = path.join(workDir, `norm_${i}.mp4`);
      await downloadTo(scenes[i].video_url, raw);
      await run('ffmpeg', [
        '-y', '-i', raw,
        '-vf', `scale=${w}:${h}:force_original_aspect_ratio=decrease,pad=${w}:${h}:(ow-iw)/2:(oh-ih)/2,fps=30`,
        '-c:v', 'libx264', '-preset', 'fast', '-c:a', 'aac',
        norm,
      ]);
      normalized.push(norm);
    }

    // 2. Concat normalized clips.
    const listFile = path.join(workDir, 'concat.txt');
    await writeFile(listFile, normalized.map((f) => `file '${f}'`).join('\n'));
    const concatOut = path.join(workDir, 'concat.mp4');
    await run('ffmpeg', ['-y', '-f', 'concat', '-safe', '0', '-i', listFile, '-c', 'copy', concatOut]);

    // 3. Mix in music/narration/SFX if present, else ship the concatenated video as-is.
    const audioInputs: string[] = [];
    if (project.music_url) audioInputs.push(project.music_url);
    // Per-scene narration/SFX mixing is added once VoiceProvider/SFXProvider
    // are wired in (next stage) — concat-only path is what's proven today.

    const finalPath = path.join(workDir, 'final.mp4');
    if (audioInputs.length === 0) {
      await run('ffmpeg', ['-y', '-i', concatOut, '-c', 'copy', finalPath]);
    } else {
      const musicLocal = path.join(workDir, 'music.mp3');
      await downloadTo(audioInputs[0], musicLocal);
      await run('ffmpeg', [
        '-y', '-i', concatOut, '-i', musicLocal,
        '-filter_complex', '[1:a]volume=0.3[music]',
        '-map', '0:v', '-map', '[music]', '-shortest', finalPath,
      ]);
    }

    // 4. Thumbnail from frame 1.
    const thumbPath = path.join(workDir, 'thumb.jpg');
    await run('ffmpeg', ['-y', '-i', finalPath, '-frames:v', '1', thumbPath]);

    // 5. Upload to Supabase Storage, update the project.
    const finalBuf = await readFile(finalPath);
    const thumbBuf = await readFile(thumbPath);
    const finalKey = `users/${project.user_id}/projects/${projectId}/final/output.mp4`;
    const thumbKey = `users/${project.user_id}/projects/${projectId}/thumbnails/thumb.jpg`;

    await supabase.storage.from('videos').upload(finalKey, finalBuf, { contentType: 'video/mp4', upsert: true });
    await supabase.storage.from('videos').upload(thumbKey, thumbBuf, { contentType: 'image/jpeg', upsert: true });
    const { data: finalUrl } = supabase.storage.from('videos').getPublicUrl(finalKey);

    await supabase.from('projects').update({
      status: 'complete', final_video_url: finalUrl.publicUrl,
    }).eq('id', projectId);

    return { finalVideoUrl: finalUrl.publicUrl };
  } finally {
    await rm(workDir, { recursive: true, force: true });
  }
}
