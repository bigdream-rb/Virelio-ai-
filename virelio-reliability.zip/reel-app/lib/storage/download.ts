import { writeFile } from 'fs/promises';
import { tmpdir } from 'os';
import path from 'path';

export async function downloadToTemp(url: string, filename: string): Promise<string> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`download failed (${res.status}): ${url}`);
  const buf = Buffer.from(await res.arrayBuffer());
  const dest = path.join(tmpdir(), filename);
  await writeFile(dest, buf);
  return dest;
}
