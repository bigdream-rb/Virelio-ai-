// Hand-rolled validator, no dependency — deliberately dependency-free so
// it can be proven correct with a plain `node` run before anything ships.
// This is the gate between "the LLM said something" and "we trust it
// enough to insert into Supabase." Never skip it.

export type ValidatedScene = {
  index: number;
  description: string;
  location?: string;
  cameraMovement?: string;
  dialogue?: string;
  narrationText?: string;
  durationSeconds: number;
  characterNames?: string[];
};

export type ValidatedScript = {
  title: string;
  summary: string;
  characters: { name: string; description?: string }[];
  scenes: ValidatedScene[];
  musicMood?: string;
};

export type ValidationResult =
  | { valid: true; data: ValidatedScript }
  | { valid: false; errors: string[] };

function isNonEmptyString(v: unknown): v is string {
  return typeof v === 'string' && v.trim().length > 0;
}

export type ValidatedOutline = {
  title: string;
  summary: string;
  characters: { name: string; description: string }[];
  beats: { summary: string; approxDurationSeconds: number }[];
};

export function validateOutline(raw: unknown): { valid: true; data: ValidatedOutline } | { valid: false; errors: string[] } {
  const errors: string[] = [];
  if (typeof raw !== 'object' || raw === null) return { valid: false, errors: ['response is not a JSON object'] };
  const obj = raw as Record<string, unknown>;

  if (!isNonEmptyString(obj.title)) errors.push('title: missing or empty');
  if (!isNonEmptyString(obj.summary)) errors.push('summary: missing or empty');

  const characters: { name: string; description: string }[] = [];
  if (!Array.isArray(obj.characters)) errors.push('characters: must be an array');
  else obj.characters.forEach((c, i) => {
    if (typeof c !== 'object' || c === null || !isNonEmptyString((c as any).name)) errors.push(`characters[${i}]: missing name`);
    else characters.push({ name: (c as any).name, description: isNonEmptyString((c as any).description) ? (c as any).description : '' });
  });

  const beats: { summary: string; approxDurationSeconds: number }[] = [];
  if (!Array.isArray(obj.beats) || obj.beats.length === 0) errors.push('beats: must be a non-empty array');
  else obj.beats.forEach((b, i) => {
    if (typeof b !== 'object' || b === null || !isNonEmptyString((b as any).summary)) { errors.push(`beats[${i}]: missing summary`); return; }
    if (typeof (b as any).approxDurationSeconds !== 'number' || (b as any).approxDurationSeconds <= 0) { errors.push(`beats[${i}].approxDurationSeconds: must be a positive number`); return; }
    beats.push({ summary: (b as any).summary, approxDurationSeconds: (b as any).approxDurationSeconds });
  });

  if (errors.length > 0) return { valid: false, errors };
  return { valid: true, data: { title: obj.title as string, summary: obj.summary as string, characters, beats } };
}

export function validateSceneBatch(raw: unknown): { valid: true; data: ValidatedScene[] } | { valid: false; errors: string[] } {
  const errors: string[] = [];
  if (!Array.isArray(raw) || raw.length === 0) return { valid: false, errors: ['response must be a non-empty array of scenes'] };
  const scenes: ValidatedScene[] = [];
  raw.forEach((s, i) => {
    if (typeof s !== 'object' || s === null) { errors.push(`scenes[${i}]: not an object`); return; }
    const sc = s as Record<string, unknown>;
    if (!isNonEmptyString(sc.description)) { errors.push(`scenes[${i}].description: missing`); return; }
    if (typeof sc.durationSeconds !== 'number' || sc.durationSeconds <= 0) { errors.push(`scenes[${i}].durationSeconds: must be a positive number`); return; }
    scenes.push({
      index: i,
      description: sc.description as string,
      location: sc.location as string | undefined,
      cameraMovement: sc.cameraMovement as string | undefined,
      dialogue: sc.dialogue as string | undefined,
      narrationText: sc.narrationText as string | undefined,
      durationSeconds: sc.durationSeconds as number,
      characterNames: Array.isArray(sc.characterNames) ? sc.characterNames as string[] : undefined,
    });
  });
  if (errors.length > 0) return { valid: false, errors };
  return { valid: true, data: scenes };
}

export function validateScript(raw: unknown): ValidationResult {
  const errors: string[] = [];
  if (typeof raw !== 'object' || raw === null) {
    return { valid: false, errors: ['response is not a JSON object'] };
  }
  const obj = raw as Record<string, unknown>;

  if (!isNonEmptyString(obj.title)) errors.push('title: missing or empty');
  if (!isNonEmptyString(obj.summary)) errors.push('summary: missing or empty');

  const characters: { name: string; description?: string }[] = [];
  if (!Array.isArray(obj.characters)) {
    errors.push('characters: must be an array');
  } else {
    obj.characters.forEach((c, i) => {
      if (typeof c !== 'object' || c === null || !isNonEmptyString((c as any).name)) {
        errors.push(`characters[${i}]: missing name`);
      } else {
        characters.push({ name: (c as any).name, description: (c as any).description });
      }
    });
  }

  const scenes: ValidatedScene[] = [];
  if (!Array.isArray(obj.scenes) || obj.scenes.length === 0) {
    errors.push('scenes: must be a non-empty array');
  } else {
    obj.scenes.forEach((s, i) => {
      if (typeof s !== 'object' || s === null) {
        errors.push(`scenes[${i}]: not an object`);
        return;
      }
      const sc = s as Record<string, unknown>;
      if (!isNonEmptyString(sc.description)) errors.push(`scenes[${i}].description: missing`);
      if (typeof sc.durationSeconds !== 'number' || sc.durationSeconds <= 0) {
        errors.push(`scenes[${i}].durationSeconds: must be a positive number`);
      }
      if (errors.some((e) => e.startsWith(`scenes[${i}]`))) return;
      scenes.push({
        index: i,
        description: sc.description as string,
        location: sc.location as string | undefined,
        cameraMovement: sc.cameraMovement as string | undefined,
        dialogue: sc.dialogue as string | undefined,
        narrationText: sc.narrationText as string | undefined,
        durationSeconds: sc.durationSeconds as number,
        characterNames: Array.isArray(sc.characterNames) ? sc.characterNames as string[] : undefined,
      });
    });
  }

  if (errors.length > 0) return { valid: false, errors };
  return {
    valid: true,
    data: { title: obj.title as string, summary: obj.summary as string, characters, scenes, musicMood: obj.musicMood as string | undefined },
  };
}
