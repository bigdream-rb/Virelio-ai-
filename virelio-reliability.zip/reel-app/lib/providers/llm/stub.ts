import type { LLMProvider, SceneDraft } from '../types';

export const stubLLMProvider: LLMProvider = {
  async generateScript({ prompt, totalDurationSeconds }) {
    const sceneCount = Math.max(1, Math.round(totalDurationSeconds / 5));
    const scenes: SceneDraft[] = Array.from({ length: sceneCount }, (_, i) => ({
      index: i, description: `[STUB] Scene ${i + 1} of "${prompt}"`, durationSeconds: 5,
      narrationText: `[STUB] Narration for scene ${i + 1}.`,
    }));
    return { title: `[STUB] ${prompt.slice(0, 40)}`, scenes };
  },
  async generateOutline({ prompt, totalDurationSeconds }) {
    const beatCount = Math.max(2, Math.round(totalDurationSeconds / 90));
    const beatDuration = totalDurationSeconds / beatCount;
    return {
      title: `[STUB] ${prompt.slice(0, 40)}`,
      summary: `[STUB] summary of "${prompt}"`,
      characters: [{ name: 'Stub Hero', description: '[STUB] a placeholder character' }],
      beats: Array.from({ length: beatCount }, (_, i) => ({ summary: `[STUB] beat ${i + 1}`, approxDurationSeconds: beatDuration })),
    };
  },
  async generateSceneBatch({ beat, startIndex }) {
    const sceneCount = Math.max(1, Math.round(beat.approxDurationSeconds / 7));
    return Array.from({ length: sceneCount }, (_, i) => ({
      index: startIndex + i, description: `[STUB] ${beat.summary} — shot ${i + 1}`, durationSeconds: 7,
      characterNames: ['Stub Hero'],
    }));
  },
};
