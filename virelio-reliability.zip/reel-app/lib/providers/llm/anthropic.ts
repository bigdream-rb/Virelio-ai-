// Real Claude API call. Untested by me — I have no network access in my
// environment — but the request shape and prompt structure follow current
// Anthropic API docs. The one part that IS proven is what happens after
// the call: validateScript() (tested separately, see schema.ts).
import type { LLMProvider } from '../types';
import { validateScript, validateOutline, validateSceneBatch } from './schema';
import { fetchWithTimeout } from '../shared/fetch-with-timeout';

async function callClaude(system: string, userMessage: string): Promise<string> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) throw new Error('ANTHROPIC_API_KEY is not set');

  const res = await fetchWithTimeout('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': apiKey, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({ model: 'claude-sonnet-4-6', max_tokens: 4000, system, messages: [{ role: 'user', content: userMessage }] }),
  }, 60000); // scripts can be long, especially the batched long-video path
  if (!res.ok) throw new Error(`Anthropic API error ${res.status}: ${(await res.text()).slice(0, 300)}`);
  const data = await res.json();
  const text = data.content?.[0]?.text;
  if (!text) throw new Error('no text content in Anthropic response');
  return text;
}

function parseJson(text: string): unknown {
  try { return JSON.parse(text); } catch { throw new Error('LLM did not return valid JSON — started with: ' + text.slice(0, 200)); }
}

const SYSTEM_PROMPT = `You write short-video scripts as strict JSON. Output ONLY valid JSON, no markdown fences, no commentary.

Schema:
{
  "title": string,
  "summary": string,
  "characters": [{ "name": string, "description": string }],
  "scenes": [{
    "description": string,      // detailed visual description for a video generator
    "location": string,
    "cameraMovement": string,   // e.g. "slow pan", "tracking shot", "static wide"
    "dialogue": string | null,
    "narrationText": string | null,
    "durationSeconds": number,
    "characterNames": string[]  // must match names in "characters"
  }],
  "musicMood": string
}

Split the story into scenes of about 5 seconds each, totaling as close to the
requested duration as possible. Prefer more short scenes over fewer long ones.`;

export const anthropicLLMProvider: LLMProvider = {
  async generateScript({ prompt, style, totalDurationSeconds }) {
    const text = await callClaude(SYSTEM_PROMPT, `Style: ${style}\nTarget duration: ${totalDurationSeconds} seconds\nStory prompt: ${prompt}`);
    const result = validateScript(parseJson(text));
    if (!result.valid) throw new Error('LLM JSON failed schema validation: ' + result.errors.join('; '));

    return {
      title: result.data.title,
      scenes: result.data.scenes.map((s) => ({
        index: s.index,
        description: s.description,
        location: s.location,
        cameraMovement: s.cameraMovement,
        dialogue: s.dialogue,
        narrationText: s.narrationText,
        durationSeconds: s.durationSeconds,
      })),
    };
  },

  // Long-video path — Phase: called once per project, regardless of
  // whether the video is 2 minutes or 30. Output stays small (a handful
  // of beats), so it fits comfortably in one response even for 1800s.
  async generateOutline({ prompt, style, totalDurationSeconds }) {
    const targetBeats = Math.max(2, Math.min(20, Math.round(totalDurationSeconds / 90))); // ~90s of story per beat
    const text = await callClaude(
      `You outline video stories as strict JSON. Output ONLY JSON, no markdown, no commentary.
Schema: { "title": string, "summary": string, "characters": [{"name": string, "description": string}], "beats": [{"summary": string, "approxDurationSeconds": number}] }
Produce roughly ${targetBeats} beats whose approxDurationSeconds sum to approximately ${totalDurationSeconds}.`,
      `Style: ${style}\nTarget total duration: ${totalDurationSeconds} seconds\nStory prompt: ${prompt}`
    );
    const result = validateOutline(parseJson(text));
    if (!result.valid) throw new Error('outline JSON failed validation: ' + result.errors.join('; '));
    return result.data;
  },

  // Called once per beat (batched), not once per scene — keeps call
  // count and per-call output both bounded for very long videos.
  async generateSceneBatch({ title, summary, characters, beat, style, startIndex }) {
    const sceneCount = Math.max(1, Math.round(beat.approxDurationSeconds / 7)); // ~5-10s/scene, per requirement #7
    const text = await callClaude(
      `You write shot-by-shot scenes as strict JSON. Output ONLY a JSON array, no markdown, no commentary.
Each element: { "description": string, "location": string, "cameraMovement": string, "dialogue": string|null, "narrationText": string|null, "durationSeconds": number, "characterNames": string[] }
Scenes should each be 5-10 seconds, summing to approximately ${beat.approxDurationSeconds} seconds. characterNames must only use names from the character list given.`,
      `Story: "${title}" — ${summary}\nCharacters: ${characters.map((c) => `${c.name} (${c.description})`).join('; ')}\nStyle: ${style}\nThis beat (continues from scene index ${startIndex}): ${beat.summary}\nProduce about ${sceneCount} scenes for this beat.`
    );
    const result = validateSceneBatch(parseJson(text));
    if (!result.valid) throw new Error('scene batch JSON failed validation: ' + result.errors.join('; '));
    return result.data;
  },
};
