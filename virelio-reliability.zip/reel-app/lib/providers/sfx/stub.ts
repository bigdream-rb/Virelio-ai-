import type { SFXProvider } from '../types';

export const stubSFXProvider: SFXProvider = {
  async generateSFX() {
    return { audioUrl: 'https://placehold.co/sfx-stub.mp3' };
  },
};
