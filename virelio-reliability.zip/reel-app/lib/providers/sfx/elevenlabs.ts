// Real ElevenLabs Sound Effects call. Same untested caveat.
import type { SFXProvider } from '../types';
import { createServiceClient } from '../../supabase/server';
import { fetchWithTimeout } from '../shared/fetch-with-timeout';

export const elevenLabsSFXProvider: SFXProvider = {
  async generateSFX({ description, durationSeconds }) {
    const apiKey = process.env.ELEVENLABS_API_KEY;
    if (!apiKey) throw new Error('ELEVENLABS_API_KEY is not set');

    const res = await fetchWithTimeout('https://api.elevenlabs.io/v1/sound-generation', {
      method: 'POST',
      headers: { 'xi-api-key': apiKey, 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: description, duration_seconds: Math.min(durationSeconds, 22) }), // API caps duration
    }, 30000);
    if (!res.ok) throw new Error(`ElevenLabs SFX failed: ${res.status} ${await res.text()}`);

    const audioBuffer = Buffer.from(await res.arrayBuffer());
    const supabase = createServiceClient();
    const path = `sfx/${crypto.randomUUID()}.mp3`;
    const { error } = await supabase.storage.from('assets').upload(path, audioBuffer, { contentType: 'audio/mpeg' });
    if (error) throw new Error(`storage upload failed: ${error.message}`);

    const { data } = supabase.storage.from('assets').getPublicUrl(path);
    return { audioUrl: data.publicUrl };
  },
};
