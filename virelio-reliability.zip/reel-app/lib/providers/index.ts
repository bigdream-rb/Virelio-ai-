import { stubLLMProvider } from './llm/stub';
import { anthropicLLMProvider } from './llm/anthropic';
import { stubImageProvider } from './image/stub';
import { replicateImageProvider } from './image/replicate';
import { stubVideoProvider } from './video/stub';
import { replicateVideoProvider } from './video/replicate';
import { stubVoiceProvider } from './voice/stub';
import { elevenLabsVoiceProvider } from './voice/elevenlabs';
import { stubMusicProvider } from './music/stub';
import { replicateMusicProvider } from './music/replicate';
import { stubSFXProvider } from './sfx/stub';
import { elevenLabsSFXProvider } from './sfx/elevenlabs';

// Each category switches independently based on whether its key is set.
// A project can run on real script + real video while voice/music/sfx
// are still stubbed, and vice versa — that's the point of the interfaces.
export const llmProvider = process.env.ANTHROPIC_API_KEY ? anthropicLLMProvider : stubLLMProvider;
export const imageProvider = process.env.REPLICATE_API_TOKEN ? replicateImageProvider : stubImageProvider; // was permanently stubbed — fixed this pass
export const videoProvider = process.env.REPLICATE_API_TOKEN ? replicateVideoProvider : stubVideoProvider;
export const voiceProvider = process.env.ELEVENLABS_API_KEY ? elevenLabsVoiceProvider : stubVoiceProvider;
export const musicProvider = process.env.REPLICATE_API_TOKEN ? replicateMusicProvider : stubMusicProvider;
export const sfxProvider = process.env.ELEVENLABS_API_KEY ? elevenLabsSFXProvider : stubSFXProvider;
