// Provider abstraction layer.
//
// Every AI vendor (Replicate, ElevenLabs, Claude, OpenAI, ...) implements
// one of these interfaces. Nothing outside this folder should ever import
// a vendor SDK directly — the job workers only ever talk to these types.
// That's what makes "swap the video provider later" a one-file change
// instead of a rewrite.

export interface SceneDraft {
  index: number;
  description: string;
  location?: string;
  cameraMovement?: string;
  dialogue?: string;
  narrationText?: string;
  durationSeconds: number;
  characterNames?: string[];
}

export interface CharacterRef {
  id: string;
  name: string;
  age?: string;
  gender?: string;
  appearance?: string;
  clothing?: string;
  personality?: string;
  referenceImageUrl?: string;
  voiceId?: string;
}

// ---- LLM: turns a prompt into a scene-by-scene script ----
export interface LLMProvider {
  generateScript(input: {
    prompt: string;
    style: string;
    totalDurationSeconds: number;
  }): Promise<{ title: string; scenes: SceneDraft[] }>;

  // Long-video path (>60s): one call for a compact outline, then many
  // small calls to expand it batch-by-batch. Keeps every LLM call's
  // output small regardless of total duration — a 30-minute video is
  // ~200+ scenes, which would never fit reliably in one response.
  generateOutline(input: {
    prompt: string;
    style: string;
    totalDurationSeconds: number;
  }): Promise<{
    title: string;
    summary: string;
    characters: { name: string; description: string }[];
    beats: { summary: string; approxDurationSeconds: number }[]; // story beats, not scenes yet
  }>;

  generateSceneBatch(input: {
    title: string;
    summary: string;
    characters: { name: string; description: string }[];
    beat: { summary: string; approxDurationSeconds: number };
    style: string;
    startIndex: number; // for continuity in the prompt, not the DB index
  }): Promise<SceneDraft[]>;
}

// ---- Image: character reference portraits ----
export interface ImageProvider {
  generateReferenceImage(input: {
    description: string;
  }): Promise<{ imageUrl: string }>;
}

// ---- Video: one clip per scene ----
export interface VideoProvider {
  generateSceneVideo(input: {
    prompt: string;
    style: string;
    aspectRatio: '16:9' | '9:16' | '1:1';
    durationSeconds: number;
    characterReferenceImageUrl?: string;
  }): Promise<{ videoUrl: string }>;
}

// ---- Voice: narration per scene ----
export interface VoiceProvider {
  synthesizeNarration(input: {
    text: string;
    voiceId?: string;
  }): Promise<{ audioUrl: string }>;
}

// ---- Music: mood-matched background track ----
export interface MusicProvider {
  generateMusic(input: {
    mood: string;
    durationSeconds: number;
  }): Promise<{ audioUrl: string }>;
}

// ---- SFX: one-off sound effects ----
export interface SFXProvider {
  generateSFX(input: {
    description: string;
    durationSeconds: number;
  }): Promise<{ audioUrl: string }>;
}
