// Real MusicGen call via Replicate. Same untested caveat as the other
// real providers — correct against current docs, unverified by me.
import type { MusicProvider } from '../types';

const MODEL = process.env.REPLICATE_MUSIC_MODEL || 'meta/musicgen';

export const replicateMusicProvider: MusicProvider = {
  async generateMusic({ mood, durationSeconds }) {
    const token = process.env.REPLICATE_API_TOKEN;
    if (!token) throw new Error('REPLICATE_API_TOKEN is not set');

    const startRes = await fetch(`https://api.replicate.com/v1/models/${MODEL}/predictions`, {
      method: 'POST',
      headers: { Authorization: `Token ${token}`, 'Content-Type': 'application/json', Prefer: 'wait=0' },
      body: JSON.stringify({ input: { prompt: `${mood} instrumental background music, no vocals`, duration: durationSeconds } }),
    });
    if (!startRes.ok) throw new Error(`replicate music start failed: ${startRes.status} ${await startRes.text()}`);
    const started = await startRes.json();

    const start = Date.now();
    while (Date.now() - start < 5 * 60 * 1000) {
      const res = await fetch(`https://api.replicate.com/v1/predictions/${started.id}`, { headers: { Authorization: `Token ${token}` } });
      const data = await res.json();
      if (data.status === 'succeeded') {
        const url = Array.isArray(data.output) ? data.output[0] : data.output;
        if (!url) throw new Error('musicgen returned no output URL');
        return { audioUrl: url };
      }
      if (data.status === 'failed' || data.status === 'canceled') throw new Error(`musicgen ${data.status}`);
      await new Promise((r) => setTimeout(r, 3000));
    }
    throw new Error('musicgen timed out');
  },
};
