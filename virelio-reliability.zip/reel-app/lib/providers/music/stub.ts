import type { MusicProvider } from '../types';

export const stubMusicProvider: MusicProvider = {
  async generateMusic() {
    return { audioUrl: 'https://placehold.co/music-stub.mp3' };
  },
};
