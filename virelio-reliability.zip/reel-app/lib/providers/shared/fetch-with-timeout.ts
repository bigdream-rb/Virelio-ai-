// Requirement #4 gap: the polling providers (video/image/music) had
// timeout handling via their poll loops, but the direct one-shot calls
// (Anthropic, ElevenLabs) had none — a hung request would wait forever
// with no error at all. This wraps fetch with an AbortController-based
// timeout so every provider call fails loudly instead of hanging.
export async function fetchWithTimeout(url: string, init: RequestInit, timeoutMs = 30000): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } catch (err: any) {
    if (err.name === 'AbortError') throw new Error(`request timed out after ${timeoutMs}ms: ${url}`);
    throw err;
  } finally {
    clearTimeout(timer);
  }
}
