// Real text-to-image call for character reference images (requirement #9).
// Untested — no network here — but follows Replicate's current API shape,
// same pattern already proven correct for the video provider.
import type { ImageProvider } from '../types';

const MODEL = process.env.REPLICATE_IMAGE_MODEL || 'black-forest-labs/flux-schnell';

export const replicateImageProvider: ImageProvider = {
  async generateReferenceImage({ description }) {
    const token = process.env.REPLICATE_API_TOKEN;
    if (!token) throw new Error('REPLICATE_API_TOKEN is not set');

    const startRes = await fetch(`https://api.replicate.com/v1/models/${MODEL}/predictions`, {
      method: 'POST',
      headers: { Authorization: `Token ${token}`, 'Content-Type': 'application/json', Prefer: 'wait=0' },
      body: JSON.stringify({ input: { prompt: `character reference portrait, ${description}, neutral background, consistent lighting`, aspect_ratio: '1:1' } }),
    });
    if (!startRes.ok) throw new Error(`replicate image start failed: ${startRes.status} ${await startRes.text()}`);
    const started = await startRes.json();

    const start = Date.now();
    while (Date.now() - start < 2 * 60 * 1000) {
      const res = await fetch(`https://api.replicate.com/v1/predictions/${started.id}`, { headers: { Authorization: `Token ${token}` } });
      const data = await res.json();
      if (data.status === 'succeeded') {
        const url = Array.isArray(data.output) ? data.output[0] : data.output;
        if (!url) throw new Error('image model returned no output URL');
        return { imageUrl: url };
      }
      if (data.status === 'failed' || data.status === 'canceled') throw new Error(`image generation ${data.status}`);
      await new Promise((r) => setTimeout(r, 2000));
    }
    throw new Error('image generation timed out');
  },
};
