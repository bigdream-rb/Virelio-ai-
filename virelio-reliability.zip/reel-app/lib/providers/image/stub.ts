import type { ImageProvider } from '../types';

export const stubImageProvider: ImageProvider = {
  async generateReferenceImage() {
    return { imageUrl: 'https://placehold.co/512x512?text=character+ref' };
  },
};
