import type { VoiceProvider } from '../types';

export const stubVoiceProvider: VoiceProvider = {
  async synthesizeNarration() {
    return { audioUrl: 'https://placehold.co/audio-stub.mp3' };
  },
};
