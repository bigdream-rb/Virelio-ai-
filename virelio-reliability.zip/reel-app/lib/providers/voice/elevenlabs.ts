// Real ElevenLabs TTS call. Untested here (no network). Uploads the
// resulting audio to Supabase Storage rather than returning ElevenLabs'
// own URL, since ElevenLabs returns raw audio bytes, not a hosted link.
import type { VoiceProvider } from '../types';
import { createServiceClient } from '../../supabase/server';
import { fetchWithTimeout } from '../shared/fetch-with-timeout';

const DEFAULT_VOICE_ID = process.env.ELEVENLABS_DEFAULT_VOICE_ID || '21m00Tcm4TlvDq8ikWAM'; // "Rachel" — ElevenLabs' standard demo voice

export const elevenLabsVoiceProvider: VoiceProvider = {
  async synthesizeNarration({ text, voiceId }) {
    const apiKey = process.env.ELEVENLABS_API_KEY;
    if (!apiKey) throw new Error('ELEVENLABS_API_KEY is not set');

    const res = await fetchWithTimeout(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId || DEFAULT_VOICE_ID}`, {
      method: 'POST',
      headers: { 'xi-api-key': apiKey, 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, model_id: 'eleven_multilingual_v2' }),
    }, 30000);
    if (!res.ok) throw new Error(`ElevenLabs TTS failed: ${res.status} ${await res.text()}`);

    const audioBuffer = Buffer.from(await res.arrayBuffer());
    const supabase = createServiceClient();
    const path = `narration/${crypto.randomUUID()}.mp3`;
    const { error } = await supabase.storage.from('assets').upload(path, audioBuffer, { contentType: 'audio/mpeg' });
    if (error) throw new Error(`storage upload failed: ${error.message}`);

    const { data } = supabase.storage.from('assets').getPublicUrl(path);
    return { audioUrl: data.publicUrl };
  },
};
