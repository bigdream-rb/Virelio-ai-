// Real Replicate video call. Untested here — no network access — but
// matches Replicate's current /v1/models/{owner}/{name}/predictions API
// and standard poll-until-done pattern.
import type { VideoProvider } from '../types';

const DEFAULT_MODEL = process.env.REPLICATE_VIDEO_MODEL || 'wan-video/wan-2.2-t2v-fast';

async function pollPrediction(id: string, token: string, timeoutMs = 5 * 60 * 1000): Promise<any> {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const res = await fetch(`https://api.replicate.com/v1/predictions/${id}`, {
      headers: { Authorization: `Token ${token}` },
    });
    const data = await res.json();
    if (data.status === 'succeeded') return data;
    if (data.status === 'failed' || data.status === 'canceled') {
      throw new Error(`replicate prediction ${data.status}: ${data.error ?? 'no error detail'}`);
    }
    await new Promise((r) => setTimeout(r, 3000));
  }
  throw new Error('replicate prediction timed out');
}

export const replicateVideoProvider: VideoProvider = {
  async generateSceneVideo({ prompt, aspectRatio, durationSeconds, characterReferenceImageUrl }) {
    const token = process.env.REPLICATE_API_TOKEN;
    if (!token) throw new Error('REPLICATE_API_TOKEN is not set');

    const input: Record<string, unknown> = {
      prompt,
      aspect_ratio: aspectRatio,
      duration: durationSeconds,
    };
    if (characterReferenceImageUrl) input.image = characterReferenceImageUrl;

    const startRes = await fetch(`https://api.replicate.com/v1/models/${DEFAULT_MODEL}/predictions`, {
      method: 'POST',
      headers: { Authorization: `Token ${token}`, 'Content-Type': 'application/json', Prefer: 'wait=0' },
      body: JSON.stringify({ input }),
    });
    if (!startRes.ok) throw new Error(`replicate start failed: ${startRes.status} ${await startRes.text()}`);
    const started = await startRes.json();

    const finished = await pollPrediction(started.id, token);
    const videoUrl = Array.isArray(finished.output) ? finished.output[0] : finished.output;
    if (!videoUrl) throw new Error('replicate returned no output URL');
    return { videoUrl };
  },
};
