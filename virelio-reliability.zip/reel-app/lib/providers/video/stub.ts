import type { VideoProvider } from '../types';

export const stubVideoProvider: VideoProvider = {
  async generateSceneVideo() {
    return { videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4' };
  },
};
