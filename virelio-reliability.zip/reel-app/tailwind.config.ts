import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        base: '#120e17',       // near-black plum
        surface: '#1a1521',
        surface2: '#221b2b',
        line: '#332a3d',
        ink: '#f3eef7',
        muted: '#a094ab',
        gold: '#f2a65a',       // primary accent — signal/coral-gold
        violet: '#8b7fd1',     // secondary accent
        good: '#6bbf8a',
        bad: '#e0645a',
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'sans-serif'],
        body: ['Inter', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      borderRadius: { xl2: '1.25rem' },
    },
  },
  plugins: [],
};
export default config;
