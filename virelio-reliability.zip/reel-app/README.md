# Virelio AI — Step 2: Core App UI

## Setup
1. `npm install`
2. Supabase project from Step 1 still applies — no schema changes.
3. Copy `.env.example` to `.env.local`, fill in Supabase values.
4. `npm run dev`, open http://localhost:3000
5. Sign up a real account at `/signup` — this creates a real Supabase auth
   user and, via the Step 1 trigger, a `profiles` row with 10 starter credits.

## Files created
- `middleware.ts` — route protection, redirects signed-out users to `/login`
- `app/login`, `app/signup` — real Supabase auth (signInWithPassword, signUp)
- `app/dashboard`, `app/create`, `app/characters`, `app/projects`,
  `app/projects/[id]`, `app/settings` — the 5 main pages + project detail
- `lib/supabase/rsc.ts` — server-component Supabase client
- `components/layout/` — Sidebar, MobileNav, Header, AppShell
- `components/ui/` — Modal, Toast, LoadingState, EmptyState
- `components/cards/` — ProjectCard, CharacterCard
- `components/create/` — StyleSelector, DurationSelector, AspectSelector, VoiceSelector, MusicSelector
- `components/project/` — GenerationProgress, VideoPlayer
- `components/brand/Logo.tsx` — Virelio wordmark + iris mark
- `tailwind.config.ts`, `app/globals.css` — brand tokens (plum/gold/violet, Space Grotesk)

## Supabase functionality actually connected
- Auth: signup, login, logout, session-based route protection — real
- Dashboard: reads real `profiles.credits` and real `projects` rows
- Create Video: writes a real row to `projects` on submit
- Characters: full real CRUD against the `characters` table
- Projects: real list, with client-side search/filter/sort
- Project detail: real queries against `projects`, `generation_jobs`, `scenes`
- Settings: profile section reads real data

## Still placeholders (marked as such in the UI, not faked)
- Voice and Music selectors — picker UI only, no real preview audio (needs VoiceProvider/MusicProvider wired to a real vendor)
- Storyboard scenes — empty until script generation exists (Step 3)
- GenerationProgress — renders real `generation_jobs` rows; shows all steps as pending because no jobs exist yet
- VideoPlayer — real component, shows empty state until a project has `final_video_url`
- Settings: Appearance, Language, Notifications, Privacy, API config — visibly disabled, not wired
- Fantasy and Sci-Fi styles — mentioned in the brief but not in the Step 1 DB enum; I didn't change the schema without asking, so these aren't offered yet

## Environment variables required
Same three as Step 1 — no new ones needed for this step:
```
NEXT_PUBLIC_SUPABASE_URL
NEXT_PUBLIC_SUPABASE_ANON_KEY
SUPABASE_SERVICE_ROLE_KEY
```

## How to test
1. Sign up → should land on `/dashboard`, showing "10 credits" and an empty-state prompt
2. Go to Create Video → fill in a prompt, pick style/duration/aspect → Generate Video → should redirect to a project detail page showing your prompt and an all-pending progress list
3. Go to Characters → create one → should appear as a card; delete should remove it
4. Go to Projects → your test project should appear; search/filter should work client-side
5. Try shrinking the browser to phone width → sidebar should become a bottom nav

## Errors / limitations
- Same as Step 1: I can't run `npm install` or `next build` here (no network access), so this hasn't been compiled by me. Please run it and send back any error verbatim.
- Characters currently attach to your *most recently created* project rather than a project you explicitly pick — a project selector for Characters is a reasonable Step 3 addition if you want it sooner.
