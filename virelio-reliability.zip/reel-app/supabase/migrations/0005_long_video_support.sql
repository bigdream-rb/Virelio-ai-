-- Redesign for durations up to 1800s (30 min). Not just raising a number:
-- new pipeline stage (character_image), stuck-job recovery, cancellation,
-- and indexes that matter once a project has hundreds of scenes/jobs.

alter type job_type add value if not exists 'character_image';
alter type project_status add value if not exists 'cancelled';
alter table generation_jobs add column character_id uuid references characters(id) on delete cascade;

alter table projects add constraint projects_duration_check check (duration_seconds > 0 and duration_seconds <= 1800);

-- Requirement #30: store final video metadata alongside the URL.
alter table projects add column final_video_metadata jsonb;

-- Needed once a project has 100+ scenes/jobs: progress counting
-- ("scene 27 of 146") and per-project job dispatch both filter on these.
create index if not exists idx_scenes_project_status on scenes(project_id, status);
create index if not exists idx_jobs_project_type_status on generation_jobs(project_id, job_type, status);
create index if not exists idx_characters_user on characters(user_id);

-- Requirement #21: recover jobs stuck in "running" (worker crashed
-- mid-job, network died, etc). Resets to queued for another attempt, or
-- fails permanently past a max-attempts cap and refunds if it was charged.
create or replace function reap_stuck_jobs(p_timeout_minutes integer default 10, p_max_attempts integer default 5)
returns integer
language plpgsql security definer set search_path = public
as $$
declare
  v_count integer := 0;
  v_job record;
begin
  for v_job in
    select * from generation_jobs
    where status = 'running' and updated_at < now() - (p_timeout_minutes || ' minutes')::interval
  loop
    if v_job.attempt_count >= p_max_attempts then
      update generation_jobs set status = 'failed', error_message = 'stuck in running past max attempts, timed out' where id = v_job.id;
      perform refund_credits_for_job(v_job.id);
    else
      update generation_jobs set status = 'queued', attempt_count = attempt_count + 1 where id = v_job.id;
    end if;
    v_count := v_count + 1;
  end loop;
  return v_count;
end;
$$;
revoke all on function reap_stuck_jobs(integer, integer) from public, anon, authenticated;
grant execute on function reap_stuck_jobs(integer, integer) to service_role;
