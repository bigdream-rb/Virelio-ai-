-- REEL — initial schema
-- Run via `supabase db push` or paste into the Supabase SQL editor.

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  display_name text,
  credits integer not null default 10,
  created_at timestamptz not null default now()
);

create type project_style as enum ('realistic','cinematic','cartoon','3d_animation','anime');
create type project_status as enum ('draft','generating','complete','failed');
create type aspect_ratio as enum ('16:9','9:16','1:1');

create table projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  title text,
  prompt text not null,
  style project_style not null default 'cinematic',
  duration_seconds integer not null default 30,
  aspect_ratio aspect_ratio not null default '16:9',
  status project_status not null default 'draft',
  final_video_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table characters (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references projects(id) on delete cascade,
  name text not null,
  age text,
  gender text,
  appearance text,
  clothing text,
  personality text,
  reference_image_url text,
  voice_id text,
  created_at timestamptz not null default now()
);

create type scene_status as enum ('pending','generating','complete','failed');

create table scenes (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references projects(id) on delete cascade,
  scene_index integer not null,
  description text,
  location text,
  camera_movement text,
  dialogue text,
  narration_text text,
  duration_seconds integer not null default 5,
  status scene_status not null default 'pending',
  video_url text,
  audio_url text,
  created_at timestamptz not null default now()
);

create table scene_characters (
  scene_id uuid not null references scenes(id) on delete cascade,
  character_id uuid not null references characters(id) on delete cascade,
  primary key (scene_id, character_id)
);

create type job_type as enum ('script','scene_video','voice','music','sfx','assemble');
create type job_status as enum ('queued','running','succeeded','failed');

create table generation_jobs (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references projects(id) on delete cascade,
  scene_id uuid references scenes(id) on delete cascade,
  job_type job_type not null,
  status job_status not null default 'queued',
  provider text,
  error_message text,
  attempt_count integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create type asset_type as enum ('video','audio','image','music','sfx','final');

create table assets (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references projects(id) on delete cascade,
  scene_id uuid references scenes(id) on delete cascade,
  type asset_type not null,
  url text not null,
  provider text,
  created_at timestamptz not null default now()
);

-- Row-level security: users only ever see their own projects and everything under them.
alter table profiles enable row level security;
alter table projects enable row level security;
alter table characters enable row level security;
alter table scenes enable row level security;
alter table scene_characters enable row level security;
alter table generation_jobs enable row level security;
alter table assets enable row level security;

create policy "own profile" on profiles for all using (auth.uid() = id);
create policy "own projects" on projects for all using (auth.uid() = user_id);

create policy "own characters" on characters for all using (
  exists (select 1 from projects where projects.id = characters.project_id and projects.user_id = auth.uid())
);
create policy "own scenes" on scenes for all using (
  exists (select 1 from projects where projects.id = scenes.project_id and projects.user_id = auth.uid())
);
create policy "own scene_characters" on scene_characters for all using (
  exists (select 1 from scenes s join projects p on p.id = s.project_id
          where s.id = scene_characters.scene_id and p.user_id = auth.uid())
);
create policy "own jobs" on generation_jobs for all using (
  exists (select 1 from projects where projects.id = generation_jobs.project_id and projects.user_id = auth.uid())
);
create policy "own assets" on assets for all using (
  exists (select 1 from projects where projects.id = assets.project_id and projects.user_id = auth.uid())
);

-- New signups get a profile row automatically.
create function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email) values (new.id, new.email);
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
