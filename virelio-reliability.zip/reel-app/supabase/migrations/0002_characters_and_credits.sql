-- Fix 1: characters should belong to the user, not be trapped inside one
-- project. Add user_id, make project_id nullable (a character can exist
-- in your library before being used anywhere), and keep scene_characters
-- as the real per-scene assignment.

alter table characters add column user_id uuid references profiles(id) on delete cascade;

-- Backfill: derive user_id from the project each existing character sits in.
update characters set user_id = projects.user_id
from projects where projects.id = characters.project_id;

alter table characters alter column user_id set not null;
alter table characters alter column project_id drop not null;

drop policy if exists "own characters" on characters;
create policy "own characters" on characters for all using (auth.uid() = user_id);

-- The old workaround (a hidden "__character_library__" project) can now
-- be deleted in application code; it's no longer needed because
-- characters have a real owner independent of any project.

-- Fix 2: a real, server-only credit transaction system. Users must never
-- be able to move their own balance — this function is the only path
-- that changes profiles.credits, and it's SECURITY DEFINER so it runs
-- with elevated rights regardless of who calls it, while still checking
-- the caller owns the project.

create table credit_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  project_id uuid references projects(id) on delete set null,
  amount integer not null,               -- negative = charge, positive = refund
  reason text not null,                  -- 'generation_reserve' | 'generation_refund' | ...
  created_at timestamptz not null default now()
);
alter table credit_transactions enable row level security;
create policy "own transactions" on credit_transactions for select using (auth.uid() = user_id);
-- No insert/update/delete policy for regular users — only the function below
-- (running as SECURITY DEFINER) can write here.

create or replace function reserve_credits(p_project_id uuid, p_amount integer)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid;
  v_balance integer;
begin
  select user_id into v_user_id from projects where id = p_project_id;
  if v_user_id is null or v_user_id != auth.uid() then
    raise exception 'not authorized for this project';
  end if;

  select credits into v_balance from profiles where id = v_user_id for update;
  if v_balance < p_amount then
    return false;
  end if;

  update profiles set credits = credits - p_amount where id = v_user_id;
  insert into credit_transactions (user_id, project_id, amount, reason)
    values (v_user_id, p_project_id, -p_amount, 'generation_reserve');
  return true;
end;
$$;

create or replace function refund_credits(p_project_id uuid, p_amount integer, p_reason text default 'generation_refund')
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid;
begin
  select user_id into v_user_id from projects where id = p_project_id;
  if v_user_id is null then
    raise exception 'project not found';
  end if;

  update profiles set credits = credits + p_amount where id = v_user_id;
  insert into credit_transactions (user_id, project_id, amount, reason)
    values (v_user_id, p_project_id, p_amount, p_reason);
end;
$$;

-- Guardrail: prevent a duplicate reserve on retry. A job retry should
-- call this to check before reserving again.
create or replace function has_reserved_credits(p_project_id uuid)
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1 from credit_transactions
    where project_id = p_project_id and reason = 'generation_reserve'
  );
$$;
