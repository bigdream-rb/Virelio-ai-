-- Step 11 finding: advanceProjectIfReady() has a real TOCTOU race. If two
-- worker processes finish the last two scene_video jobs for the same
-- project within milliseconds of each other, both can independently
-- observe "voice stage not started" and both insert a full set of voice
-- jobs — real duplicate work and duplicate charges. Application-level
-- "check then insert" can never fully close this race; the fix has to be
-- a DB constraint that makes the duplicate insert itself fail/no-op.

-- Per-scene stages: exactly one job per (scene, job_type).
create unique index if not exists idx_jobs_unique_scene_stage
  on generation_jobs(project_id, scene_id, job_type)
  where scene_id is not null;

-- Per-character stage: exactly one job per (character, job_type).
create unique index if not exists idx_jobs_unique_character_stage
  on generation_jobs(project_id, character_id, job_type)
  where character_id is not null;

-- Project-level singleton stages (script, music, assemble): exactly one
-- job per (project, job_type) among rows with no scene_id/character_id.
create unique index if not exists idx_jobs_unique_project_stage
  on generation_jobs(project_id, job_type)
  where scene_id is null and character_id is null;
