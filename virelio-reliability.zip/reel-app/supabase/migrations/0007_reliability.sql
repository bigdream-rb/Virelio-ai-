-- Step 3 (production reliability): resumable script generation needs
-- somewhere durable to persist the outline and progress checkpoint so a
-- retry can continue from the last completed beat instead of restarting
-- (which would also collide with the scene_index unique constraint from
-- migration 0005 if it blindly re-inserted already-completed scenes).
alter table projects add column script_outline jsonb;
alter table projects add column script_beats_completed integer not null default 0;

-- Cancellation: queued jobs for a cancelled project should be visibly
-- cancelled, not just ignored — otherwise they'd sit as "queued" forever
-- looking like the pipeline is still working.
create or replace function cancel_project(p_project_id uuid)
returns void
language plpgsql security definer set search_path = public
as $$
begin
  -- Ownership check happens in the calling API route via the user's own
  -- session (RLS-scoped client), not here — this function just does the
  -- privileged multi-table update once that check has already passed.
  update projects set status = 'cancelled' where id = p_project_id;
  update generation_jobs set status = 'cancelled'
    where project_id = p_project_id and status = 'queued';
  -- Jobs already 'running' are intentionally left alone — there is no
  -- safe way to abort a provider call that's already in flight without
  -- threading an AbortController through every provider (a bigger change
  -- than this pass covers). They'll finish naturally; their results are
  -- simply never used because advanceProjectIfReady already refuses to
  -- advance a cancelled project. Documented limitation, not hidden.
end;
$$;
revoke all on function cancel_project(uuid) from public, anon, authenticated;
grant execute on function cancel_project(uuid) to service_role;
