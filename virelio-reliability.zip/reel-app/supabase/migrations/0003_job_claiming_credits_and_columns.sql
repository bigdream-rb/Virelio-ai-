-- Phase 4: concurrency-safe job claiming. FOR UPDATE SKIP LOCKED means
-- two worker processes can poll simultaneously without ever grabbing the
-- same job — the second one just skips rows the first already locked.
create or replace function claim_generation_jobs(p_batch_size integer default 5)
returns setof generation_jobs
language plpgsql
security definer
set search_path = public
as $$
begin
  return query
  update generation_jobs
  set status = 'running', updated_at = now()
  where id in (
    select id from generation_jobs
    where status = 'queued'
    order by created_at
    for update skip locked
    limit p_batch_size
  )
  returning *;
end;
$$;
revoke execute on function claim_generation_jobs(integer) from public, authenticated, anon;
grant execute on function claim_generation_jobs(integer) to service_role;

-- Phase 2: the real bug — reserve_credits() from migration 0002 checks
-- auth.uid(), but the worker runs on the service-role key with no user
-- session at all, so every charge from the worker would silently fail
-- (v_user_id != auth.uid() is never true when auth.uid() is null).
-- Fix: charge per JOB, not per authenticated request, with the job's
-- own id as the idempotency key — a job can only ever be charged once,
-- checkable independent of who's asking.
alter table credit_transactions add column generation_job_id uuid references generation_jobs(id) on delete set null;
create unique index credit_transactions_one_charge_per_job on credit_transactions(generation_job_id) where reason = 'charge';

create or replace function charge_credits_for_job(p_job_id uuid, p_amount integer)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_project_id uuid;
  v_user_id uuid;
  v_balance integer;
begin
  select project_id into v_project_id from generation_jobs where id = p_job_id;
  if v_project_id is null then raise exception 'job % not found', p_job_id; end if;
  select user_id into v_user_id from projects where id = v_project_id;
  if v_user_id is null then raise exception 'project for job % not found', p_job_id; end if;

  -- Idempotent: a retried job that already succeeded in charging returns
  -- true without charging again.
  if exists (select 1 from credit_transactions where generation_job_id = p_job_id and reason = 'charge') then
    return true;
  end if;

  select credits into v_balance from profiles where id = v_user_id for update;
  if v_balance < p_amount then
    return false;
  end if;

  update profiles set credits = credits - p_amount where id = v_user_id;
  insert into credit_transactions (user_id, project_id, generation_job_id, amount, reason)
    values (v_user_id, v_project_id, p_job_id, -p_amount, 'charge');
  return true;
end;
$$;

create or replace function refund_credits_for_job(p_job_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_charge credit_transactions%rowtype;
begin
  select * into v_charge from credit_transactions where generation_job_id = p_job_id and reason = 'charge';
  if not found then return; end if; -- nothing was ever charged for this job — nothing to refund
  if exists (select 1 from credit_transactions where generation_job_id = p_job_id and reason = 'refund') then
    return; -- already refunded — idempotent, a second retry-failure won't double-refund
  end if;
  update profiles set credits = credits + (-v_charge.amount) where id = v_charge.user_id;
  insert into credit_transactions (user_id, project_id, generation_job_id, amount, reason)
    values (v_charge.user_id, v_charge.project_id, p_job_id, -v_charge.amount, 'refund');
end;
$$;

-- Only the worker (service_role key) may call these — never the browser,
-- and no dependency on which user, if any, is logged in.
revoke execute on function charge_credits_for_job(uuid, integer) from public, authenticated, anon;
revoke execute on function refund_credits_for_job(uuid) from public, authenticated, anon;
grant execute on function charge_credits_for_job(uuid, integer) to service_role;
grant execute on function refund_credits_for_job(uuid) to service_role;

-- The old auth.uid()-based reserve_credits/refund_credits from 0002 are
-- no longer called anywhere after this migration — left in place rather
-- than dropped, in case anything still references them, but nothing
-- in worker/ uses them from this point on.

-- Phase 7: missing columns + integrity constraints.
alter table projects add column if not exists music_mood text;
alter table projects add column if not exists voice_id text;
alter table projects add column if not exists generation_started_at timestamptz;
alter table projects add column if not exists generation_completed_at timestamptz;

alter table scenes add constraint scenes_project_index_unique unique (project_id, scene_index);

create index if not exists idx_generation_jobs_status_created on generation_jobs(status, created_at);
create index if not exists idx_generation_jobs_project on generation_jobs(project_id);
create index if not exists idx_scenes_project_index on scenes(project_id, scene_index);
create index if not exists idx_assets_project_type on assets(project_id, type);

create or replace function set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end;
$$;
drop trigger if exists projects_updated_at on projects;
create trigger projects_updated_at before update on projects for each row execute procedure set_updated_at();
drop trigger if exists generation_jobs_updated_at on generation_jobs;
create trigger generation_jobs_updated_at before update on generation_jobs for each row execute procedure set_updated_at();
