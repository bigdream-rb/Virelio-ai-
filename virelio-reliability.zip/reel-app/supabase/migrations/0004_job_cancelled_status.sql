-- Add "cancelled" to the job status lifecycle (pending/processing/completed/
-- failed/cancelled was requested). Keeping the existing queued/running/
-- succeeded/failed names rather than renaming them — renaming would touch
-- every file that already reads job.status for no functional gain. Adding
-- the missing state instead.
alter type job_status add value if not exists 'cancelled';
