import Link from 'next/link';
import { Logo } from '@/components/brand/Logo';

export default function LandingPage() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-6 text-center">
      <div className="mb-6"><Logo size={36} /></div>
      <h1 className="font-display text-3xl font-bold max-w-md">Turn a prompt into a finished video.</h1>
      <p className="text-muted mt-3 max-w-sm">Story, scenes, narration, music, and sound — one pipeline.</p>
      <div className="flex gap-3 mt-8">
        <Link href="/signup" className="signal-sweep bg-gold text-base font-semibold rounded-xl2 px-6 py-3">Get started</Link>
        <Link href="/login" className="border border-line rounded-xl2 px-6 py-3 text-ink">Log in</Link>
      </div>
    </main>
  );
}
