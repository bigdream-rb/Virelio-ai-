'use client';
import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { AppShell } from '@/components/layout/AppShell';

function ComingSoonSection({ title }: { title: string }) {
  return (
    <div className="bg-surface border border-line rounded-xl2 p-5 opacity-60">
      <div className="flex items-center justify-between">
        <p className="font-display font-semibold text-sm">{title}</p>
        <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-surface2">coming soon</span>
      </div>
    </div>
  );
}

export default function SettingsPage() {
  const supabase = createClient();
  const [profile, setProfile] = useState<{ email: string; credits: number } | null>(null);

  useEffect(() => {
    supabase.auth.getUser().then(async ({ data: { user } }) => {
      const { data } = await supabase.from('profiles').select('credits').eq('id', user!.id).single();
      setProfile({ email: user!.email!, credits: data?.credits ?? 0 });
    });
  }, []);

  return (
    <AppShell email={profile?.email} credits={profile?.credits}>
      <h1 className="font-display text-2xl font-bold mb-6">Settings</h1>

      <div className="max-w-lg space-y-4">
        <div className="bg-surface border border-line rounded-xl2 p-5">
          <p className="font-display font-semibold text-sm mb-3">Profile</p>
          <p className="text-sm text-muted">Email</p>
          <p className="text-sm mb-3">{profile?.email ?? '—'}</p>
          <p className="text-sm text-muted">Credits</p>
          <p className="font-mono text-gold">{profile?.credits ?? '—'}</p>
        </div>

        <ComingSoonSection title="Appearance" />
        <ComingSoonSection title="Language" />
        <ComingSoonSection title="Notifications" />
        <ComingSoonSection title="Privacy" />
        <ComingSoonSection title="API / provider configuration (dev only)" />
      </div>
    </AppShell>
  );
}
