// Fixes audit finding #1 — Create Video only made a project row before;
// nothing ever queued the script job. This route is the missing link.
// Auth comes from the request's own Supabase session (cookies), never
// from a client-supplied user_id — ownership is enforced by that session
// plus an explicit project.user_id check, not trusted input.
import { NextRequest, NextResponse } from 'next/server';
import { createServerClient } from '@supabase/ssr';

export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id: projectId } = await params;
  const cookieStore = request.cookies;

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    { cookies: { getAll: () => cookieStore.getAll(), setAll: () => {} } }
  );

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ success: false, error: 'not authenticated' }, { status: 401 });

  const { data: project } = await supabase.from('projects').select('*').eq('id', projectId).single();
  if (!project) return NextResponse.json({ success: false, error: 'project not found' }, { status: 404 });
  if (project.user_id !== user.id) return NextResponse.json({ success: false, error: 'not authorized' }, { status: 403 });

  const body = await request.json().catch(() => ({}));
  const regenerate = body?.regenerate === true;

  if (project.status === 'generating' && !regenerate) {
    return NextResponse.json({ success: false, error: 'project is already generating' }, { status: 409 });
  }
  if (!project.prompt?.trim()) {
    return NextResponse.json({ success: false, error: 'project has no prompt' }, { status: 400 });
  }
  const VALID_STYLES = ['realistic', 'cinematic', 'cartoon', '3d_animation', 'anime'];
  const VALID_ASPECT = ['16:9', '9:16', '1:1'];
  if (!VALID_STYLES.includes(project.style)) return NextResponse.json({ success: false, error: 'invalid style' }, { status: 400 });
  if (!VALID_ASPECT.includes(project.aspect_ratio)) return NextResponse.json({ success: false, error: 'invalid aspect ratio' }, { status: 400 });
  // Requirement #31: real cap at 1800s (30 min), enforced here AND by a
  // DB check constraint (migration 0005) — not just a UI limit.
  if (!project.duration_seconds || project.duration_seconds <= 0 || project.duration_seconds > 1800) {
    return NextResponse.json({ success: false, error: 'duration must be between 1 and 1800 seconds' }, { status: 400 });
  }

  const { error: jobErr } = await supabase.from('generation_jobs').insert({
    project_id: projectId, job_type: 'script', status: 'queued',
  });
  if (jobErr) return NextResponse.json({ success: false, error: jobErr.message }, { status: 500 });

  await supabase.from('projects').update({
    status: 'generating', generation_started_at: new Date().toISOString(),
  }).eq('id', projectId);

  return NextResponse.json({ success: true, projectId });
}
