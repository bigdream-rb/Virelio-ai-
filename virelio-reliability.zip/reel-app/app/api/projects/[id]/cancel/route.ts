// Ownership is enforced by the caller's own Supabase session (cookies),
// same pattern as the generate route — never trust a client-supplied
// user_id. The actual cancellation is a service-role RPC (cancel_project)
// because it needs to touch generation_jobs rows across the whole
// project, not just ones the calling session's RLS would otherwise see
// a path to update in one statement.
import { NextRequest, NextResponse } from 'next/server';
import { createServerClient } from '@supabase/ssr';
import { createServiceClient } from '../../../../../lib/supabase/server';

export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id: projectId } = await params;
  const cookieStore = request.cookies;

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    { cookies: { getAll: () => cookieStore.getAll(), setAll: () => {} } }
  );

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ success: false, error: 'not authenticated' }, { status: 401 });

  const { data: project } = await supabase.from('projects').select('user_id, status').eq('id', projectId).single();
  if (!project) return NextResponse.json({ success: false, error: 'project not found' }, { status: 404 });
  if (project.user_id !== user.id) return NextResponse.json({ success: false, error: 'not authorized' }, { status: 403 });
  if (project.status !== 'generating') {
    return NextResponse.json({ success: false, error: `project is not generating (status: ${project.status})` }, { status: 409 });
  }

  const service = createServiceClient();
  const { error } = await service.rpc('cancel_project', { p_project_id: projectId });
  if (error) return NextResponse.json({ success: false, error: error.message }, { status: 500 });

  return NextResponse.json({ success: true });
}
