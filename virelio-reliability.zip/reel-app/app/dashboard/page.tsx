import { createServerComponentClient } from '@/lib/supabase/rsc';
import { AppShell } from '@/components/layout/AppShell';
import { ProjectCard } from '@/components/cards/ProjectCard';
import { EmptyState } from '@/components/ui/EmptyState';
import Link from 'next/link';

export default async function DashboardPage() {
  const supabase = await createServerComponentClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: profile } = await supabase.from('profiles').select('credits').eq('id', user!.id).single();
  const { data: projects } = await supabase
    .from('projects').select('*').order('created_at', { ascending: false }).limit(6);

  return (
    <AppShell email={user?.email} credits={profile?.credits}>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl font-bold">Dashboard</h1>
          <p className="text-muted text-sm mt-1">Pick up a project or start something new.</p>
        </div>
        <Link href="/create" className="signal-sweep bg-gold text-base font-semibold rounded-xl2 px-5 py-2.5 text-sm">
          Create New Video
        </Link>
      </div>

      <h2 className="font-display font-semibold text-sm text-muted mb-3">Recent projects</h2>
      {projects && projects.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {projects.map((p) => <ProjectCard key={p.id} project={p} />)}
        </div>
      ) : (
        <EmptyState title="No projects yet" body="Your first video starts with a prompt."
          action={<Link href="/create" className="text-gold text-sm font-medium">Create your first video →</Link>} />
      )}
    </AppShell>
  );
}
