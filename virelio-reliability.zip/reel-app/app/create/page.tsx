'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { AppShell } from '@/components/layout/AppShell';
import { StyleSelector } from '@/components/create/StyleSelector';
import { DurationSelector } from '@/components/create/DurationSelector';
import { AspectSelector } from '@/components/create/AspectSelector';
import { VoiceSelector } from '@/components/create/VoiceSelector';
import { MusicSelector } from '@/components/create/MusicSelector';
import { useToast } from '@/components/ui/Toast';

// Rough credit estimate shown before generation — tune this once real
// provider costs are known (Step 5+). Not billed yet; informational only.
function estimateCredits(durationSeconds: number) {
  return Math.max(1, Math.round(durationSeconds / 5));
}

export default function CreatePage() {
  const router = useRouter();
  const supabase = createClient();
  const toast = useToast();

  const [prompt, setPrompt] = useState('');
  const [style, setStyle] = useState('cinematic');
  const [duration, setDuration] = useState(15);
  const [aspect, setAspect] = useState('16:9');
  const [mood, setMood] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit() {
    if (!prompt.trim()) { toast('Describe the video first', 'error'); return; }
    setSubmitting(true);
    const { data: { user } } = await supabase.auth.getUser();
    const { data, error } = await supabase.from('projects').insert({
      user_id: user!.id,
      title: prompt.slice(0, 60),
      prompt,
      style,
      duration_seconds: duration,
      aspect_ratio: aspect,
      music_mood: mood,
      status: 'draft',
    }).select().single();
    if (error) { setSubmitting(false); toast(error.message, 'error'); return; }

    // Phase 1 fix: this call is what actually queues the script job.
    // Before, the project was created and nothing ever generated.
    const res = await fetch(`/api/projects/${data.id}/generate`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
    const genResult = await res.json();
    setSubmitting(false);
    if (!genResult.success) { toast(genResult.error ?? 'could not start generation', 'error'); router.push(`/projects/${data.id}`); return; }

    toast('Generation started');
    router.push(`/projects/${data.id}`);
  }

  return (
    <AppShell>
      <h1 className="font-display text-2xl font-bold mb-1">Create Video</h1>
      <p className="text-muted text-sm mb-8">Describe the video you want to create.</p>

      <div className="max-w-2xl space-y-8">
        <div>
          <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)}
            placeholder="A young explorer discovers a mysterious ancient city hidden inside a jungle."
            rows={4}
            className="w-full bg-surface border border-line rounded-xl2 px-4 py-3 text-ink placeholder:text-muted/60 focus:outline-none focus:border-gold resize-none" />
        </div>

        <div>
          <p className="text-xs uppercase tracking-wider text-muted mb-3 font-mono">Video style</p>
          <StyleSelector value={style} onChange={setStyle} />
          <p className="text-xs text-muted mt-2">Fantasy and Sci-Fi are planned but not in the current schema yet.</p>
        </div>

        <div>
          <p className="text-xs uppercase tracking-wider text-muted mb-3 font-mono">Duration</p>
          <DurationSelector value={duration} onChange={setDuration} />
        </div>

        <div>
          <p className="text-xs uppercase tracking-wider text-muted mb-3 font-mono">Aspect ratio</p>
          <AspectSelector value={aspect} onChange={setAspect} />
        </div>

        <div>
          <p className="text-xs uppercase tracking-wider text-muted mb-3 font-mono">Voice</p>
          <VoiceSelector />
        </div>

        <div>
          <p className="text-xs uppercase tracking-wider text-muted mb-3 font-mono">Music mood</p>
          <MusicSelector value={mood} onChange={setMood} />
        </div>

        <div className="border-t border-line pt-6 flex items-center justify-between">
          <div>
            <p className="text-sm text-muted">Estimated cost</p>
            <p className="font-mono text-gold">{estimateCredits(duration)} credits</p>
          </div>
          <button onClick={handleSubmit} disabled={submitting}
            className="signal-sweep bg-gold text-base font-semibold rounded-xl2 px-6 py-3 disabled:opacity-50">
            {submitting ? 'Creating…' : 'Generate Video'}
          </button>
        </div>
        <p className="text-xs text-muted">
          This creates the project and immediately queues real script generation.
          You'll land on the project page and watch live progress from there.
        </p>
      </div>
    </AppShell>
  );
}
