'use client';
import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { AppShell } from '@/components/layout/AppShell';
import { CharacterCard } from '@/components/cards/CharacterCard';
import { EmptyState } from '@/components/ui/EmptyState';
import { LoadingState } from '@/components/ui/LoadingState';
import { Modal } from '@/components/ui/Modal';
import { useToast } from '@/components/ui/Toast';

type Character = { id: string; name: string; age: string | null; gender: string | null; appearance: string | null };

export default function CharactersPage() {
  const supabase = createClient();
  const toast = useToast();
  const [characters, setCharacters] = useState<Character[] | null>(null);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: '', age: '', gender: '', appearance: '', clothing: '', personality: '' });

  async function load() {
    // Fixed after the Step 3 audit: characters are user-scoped now
    // (migration 0002), not trapped behind a hidden holding project.
    const { data } = await supabase.from('characters').select('*').order('created_at');
    setCharacters(data ?? []);
  }

  useEffect(() => { load(); }, []);

  async function handleCreate() {
    if (!form.name.trim()) { toast('Name is required', 'error'); return; }
    const { data: { user } } = await supabase.auth.getUser();
    const { error } = await supabase.from('characters').insert({ user_id: user!.id, ...form });
    if (error) { toast(error.message, 'error'); return; }
    setOpen(false);
    setForm({ name: '', age: '', gender: '', appearance: '', clothing: '', personality: '' });
    toast('Character created');
    load();
  }

  async function handleDelete(id: string) {
    await supabase.from('characters').delete().eq('id', id);
    load();
  }

  return (
    <AppShell>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl font-bold">Characters</h1>
          <p className="text-muted text-sm mt-1">Reusable across every project.</p>
        </div>
        <button onClick={() => setOpen(true)} className="signal-sweep bg-gold text-base font-semibold rounded-xl2 px-5 py-2.5 text-sm">
          Create Character
        </button>
      </div>

      {characters === null ? <LoadingState /> : characters.length === 0 ? (
        <EmptyState title="No characters yet" body="Create one to keep faces and voices consistent across scenes." />
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {characters.map((c) => <CharacterCard key={c.id} character={c} onDelete={handleDelete} />)}
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="Create Character">
        <div className="space-y-3">
          {(['name', 'age', 'gender', 'appearance', 'clothing', 'personality'] as const).map((field) => (
            <input key={field} placeholder={field[0].toUpperCase() + field.slice(1)}
              value={form[field]} onChange={(e) => setForm({ ...form, [field]: e.target.value })}
              className="w-full bg-surface2 border border-line rounded-xl2 px-3 py-2 text-sm focus:outline-none focus:border-gold" />
          ))}
          <p className="text-xs text-muted">Reference image upload and voice picker connect once ImageProvider / VoiceProvider are wired in.</p>
          <button onClick={handleCreate} className="w-full bg-gold text-base font-semibold rounded-xl2 py-2.5 text-sm">
            Save character
          </button>
        </div>
      </Modal>
    </AppShell>
  );
}
