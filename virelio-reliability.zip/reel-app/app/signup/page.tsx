'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { Logo } from '@/components/brand/Logo';

export default function SignupPage() {
  const router = useRouter();
  const supabase = createClient();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const { error } = await supabase.auth.signUp({ email, password });
    setLoading(false);
    if (error) { setError(error.message); return; }
    // If email confirmation is on in Supabase settings, there's no session yet.
    const { data: { session } } = await supabase.auth.getSession();
    if (session) { router.push('/dashboard'); router.refresh(); }
    else { setSent(true); }
  }

  if (sent) {
    return (
      <main className="min-h-screen flex items-center justify-center px-6">
        <div className="w-full max-w-sm text-center">
          <div className="mb-8 flex justify-center"><Logo /></div>
          <h1 className="font-display text-xl font-bold mb-2">Check your email</h1>
          <p className="text-muted text-sm">We sent a confirmation link to {email}.</p>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <div className="w-full max-w-sm">
        <div className="mb-8"><Logo /></div>
        <h1 className="font-display text-2xl font-bold mb-1">Create your account</h1>
        <p className="text-muted text-sm mb-8">Start turning prompts into video.</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs uppercase tracking-wider text-muted mb-2 font-mono">Email</label>
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-surface border border-line rounded-xl2 px-4 py-3 text-ink focus:outline-none focus:border-gold" />
          </div>
          <div>
            <label className="block text-xs uppercase tracking-wider text-muted mb-2 font-mono">Password</label>
            <input type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-surface border border-line rounded-xl2 px-4 py-3 text-ink focus:outline-none focus:border-gold" />
          </div>
          {error && <p className="text-bad text-sm">{error}</p>}
          <button disabled={loading} type="submit"
            className="signal-sweep w-full bg-gold text-base font-semibold rounded-xl2 py-3 disabled:opacity-50">
            {loading ? 'Creating account…' : 'Sign up'}
          </button>
        </form>
        <p className="text-sm text-muted mt-6">
          Already have an account? <a href="/login" className="text-gold">Log in</a>
        </p>
      </div>
    </main>
  );
}
