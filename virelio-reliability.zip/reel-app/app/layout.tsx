import './globals.css';
import { ToastProvider } from '@/components/ui/Toast';

export const metadata = { title: 'Virelio AI', description: 'Text to motion picture & sound' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="font-body bg-base text-ink">
        <ToastProvider>{children}</ToastProvider>
      </body>
    </html>
  );
}
