'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { Logo } from '@/components/brand/Logo';

export default function LoginPage() {
  const router = useRouter();
  const supabase = createClient();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) { setError(error.message); return; }
    router.push('/dashboard');
    router.refresh();
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <div className="w-full max-w-sm">
        <div className="mb-8"><Logo /></div>
        <h1 className="font-display text-2xl font-bold mb-1">Welcome back</h1>
        <p className="text-muted text-sm mb-8">Log in to keep working on your videos.</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs uppercase tracking-wider text-muted mb-2 font-mono">Email</label>
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-surface border border-line rounded-xl2 px-4 py-3 text-ink focus:outline-none focus:border-gold" />
          </div>
          <div>
            <label className="block text-xs uppercase tracking-wider text-muted mb-2 font-mono">Password</label>
            <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-surface border border-line rounded-xl2 px-4 py-3 text-ink focus:outline-none focus:border-gold" />
          </div>
          {error && <p className="text-bad text-sm">{error}</p>}
          <button disabled={loading} type="submit"
            className="signal-sweep w-full bg-gold text-base font-semibold rounded-xl2 py-3 disabled:opacity-50">
            {loading ? 'Logging in…' : 'Log in'}
          </button>
        </form>
        <p className="text-sm text-muted mt-6">
          No account? <a href="/signup" className="text-gold">Sign up</a>
        </p>
      </div>
    </main>
  );
}
