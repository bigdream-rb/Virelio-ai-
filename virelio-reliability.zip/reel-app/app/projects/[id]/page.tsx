'use client';
import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { AppShell } from '@/components/layout/AppShell';
import { GenerationProgress } from '@/components/project/GenerationProgress';
import { VideoPlayer } from '@/components/project/VideoPlayer';
import { EmptyState } from '@/components/ui/EmptyState';
import { LoadingState } from '@/components/ui/LoadingState';
import { useToast } from '@/components/ui/Toast';

const SCENES_PAGE_SIZE = 30;

export default function ProjectDetailPage() {
  const { id } = useParams<{ id: string }>();
  const supabase = createClient();
  const toast = useToast();
  const [project, setProject] = useState<any>(null);
  const [scenes, setScenes] = useState<any[]>([]);
  const [sceneCount, setSceneCount] = useState(0);
  const [scenesShown, setScenesShown] = useState(SCENES_PAGE_SIZE);
  const [jobs, setJobs] = useState<any[]>([]);
  const [cancelling, setCancelling] = useState(false);

  useEffect(() => {
    let stopped = false;
    async function load() {
      // Requirement #2: a 30-minute project can have 250+ scenes — only
      // fetch the currently-visible page, not every scene every poll.
      const [{ data: p }, { data: s, count }, { data: j }] = await Promise.all([
        supabase.from('projects').select('*').eq('id', id).single(),
        supabase.from('scenes').select('*', { count: 'exact' }).eq('project_id', id).order('scene_index').range(0, scenesShown - 1),
        supabase.from('generation_jobs').select('*').eq('project_id', id),
      ]);
      if (stopped) return;
      setProject(p);
      setScenes(s ?? []);
      setSceneCount(count ?? 0);
      setJobs(j ?? []);
    }
    load();
    const interval = setInterval(() => {
      if (project?.status === 'generating' || project === null) load();
    }, 3000);
    return () => { stopped = true; clearInterval(interval); };
  }, [id, project?.status, scenesShown]);

  async function handleCancel() {
    setCancelling(true);
    const res = await fetch(`/api/projects/${id}/cancel`, { method: 'POST' });
    const result = await res.json();
    setCancelling(false);
    if (!result.success) { toast(result.error || 'could not cancel', 'error'); return; }
    toast('Generation cancelled');
    setProject((prev: any) => prev ? { ...prev, status: 'cancelled' } : prev);
  }

  if (!project) return <AppShell><LoadingState /></AppShell>;

  return (
    <AppShell>
      <div className="flex items-start justify-between mb-1">
        <h1 className="font-display text-2xl font-bold">{project.title || project.prompt}</h1>
        {project.status === 'generating' && (
          <button onClick={handleCancel} disabled={cancelling}
            className="text-sm text-bad border border-bad/40 rounded-xl2 px-4 py-2 hover:bg-bad/10 disabled:opacity-50 shrink-0 ml-4">
            {cancelling ? 'Cancelling…' : 'Cancel generation'}
          </button>
        )}
      </div>
      <p className="text-muted text-sm mb-8">{project.style} · {project.duration_seconds}s · {project.aspect_ratio}</p>

      <div className="grid lg:grid-cols-[1fr_320px] gap-6">
        <div className="space-y-6">
          <VideoPlayer url={project.final_video_url} />

          <div>
            <h2 className="font-display font-semibold text-sm text-muted mb-3">
              Storyboard{sceneCount > 0 ? ` — ${scenes.length} of ${sceneCount}` : ''}
            </h2>
            {scenes.length === 0 ? (
              <EmptyState title="No scenes yet"
                body="Script generation and scene planning connect in the next backend step. This page will fill in automatically once that's wired up — nothing here is simulated." />
            ) : (
              <>
                <div className="space-y-3">
                  {scenes.map((s) => (
                    <div key={s.id} className="bg-surface border border-line rounded-xl2 p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-mono text-xs text-muted">Scene {s.scene_index + 1}</span>
                        <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-surface2">{s.status}</span>
                      </div>
                      <p className="text-sm">{s.description}</p>
                    </div>
                  ))}
                </div>
                {scenesShown < sceneCount && (
                  <div className="flex justify-center mt-4">
                    <button onClick={() => setScenesShown((n) => n + SCENES_PAGE_SIZE)}
                      className="border border-line rounded-xl2 px-5 py-2.5 text-sm text-muted hover:text-ink">
                      Load more scenes ({sceneCount - scenesShown} remaining)
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>

        <GenerationProgress jobs={jobs} />
      </div>
    </AppShell>
  );
}
