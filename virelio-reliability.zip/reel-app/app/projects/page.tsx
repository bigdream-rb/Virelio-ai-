'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/client';
import { AppShell } from '@/components/layout/AppShell';
import { ProjectCard } from '@/components/cards/ProjectCard';
import { EmptyState } from '@/components/ui/EmptyState';
import { LoadingState } from '@/components/ui/LoadingState';

type Project = { id: string; title: string | null; prompt: string; style: string; duration_seconds: number; status: string; created_at: string };
const STATUSES = ['all', 'draft', 'generating', 'complete', 'failed'];
const PAGE_SIZE = 24;

export default function ProjectsPage() {
  const supabase = createClient();
  const [projects, setProjects] = useState<Project[] | null>(null);
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('all');
  const [sort, setSort] = useState<'newest' | 'oldest'>('newest');

  // Requirement #2: don't pull every project into the browser at once —
  // fetch in pages. Search/status filtering below only applies to what's
  // been loaded so far, not the whole account; "Load more" widens that
  // set. A project with thousands of entries won't hang the page on load.
  async function loadPage(pageIndex: number) {
    const from = pageIndex * PAGE_SIZE;
    const to = from + PAGE_SIZE - 1;
    const { data } = await supabase.from('projects').select('*').neq('title', '__character_library__')
      .order('created_at', { ascending: false }).range(from, to);
    setHasMore((data ?? []).length === PAGE_SIZE);
    return data ?? [];
  }

  useEffect(() => {
    loadPage(0).then((data) => { setProjects(data); setPage(0); });
  }, []);

  async function handleLoadMore() {
    setLoadingMore(true);
    const next = page + 1;
    const data = await loadPage(next);
    setProjects((prev) => [...(prev ?? []), ...data]);
    setPage(next);
    setLoadingMore(false);
  }

  const filtered = (projects ?? [])
    .filter((p) => status === 'all' || p.status === status)
    .filter((p) => (p.title ?? p.prompt).toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => sort === 'newest'
      ? +new Date(b.created_at) - +new Date(a.created_at)
      : +new Date(a.created_at) - +new Date(b.created_at));

  return (
    <AppShell>
      <h1 className="font-display text-2xl font-bold mb-6">Projects</h1>

      <div className="flex flex-wrap gap-3 mb-6">
        <input placeholder="Search projects…" value={search} onChange={(e) => setSearch(e.target.value)}
          className="bg-surface border border-line rounded-xl2 px-4 py-2 text-sm flex-1 min-w-[180px] focus:outline-none focus:border-gold" />
        <select value={status} onChange={(e) => setStatus(e.target.value)}
          className="bg-surface border border-line rounded-xl2 px-3 py-2 text-sm">
          {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <select value={sort} onChange={(e) => setSort(e.target.value as any)}
          className="bg-surface border border-line rounded-xl2 px-3 py-2 text-sm">
          <option value="newest">Newest first</option>
          <option value="oldest">Oldest first</option>
        </select>
      </div>

      {projects === null ? <LoadingState /> : filtered.length === 0 ? (
        <EmptyState title="No projects match" body="Try a different search or filter."
          action={<Link href="/create" className="text-gold text-sm font-medium">Create a video →</Link>} />
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map((p) => <ProjectCard key={p.id} project={p} />)}
          </div>
          {hasMore && (
            <div className="flex justify-center mt-6">
              <button onClick={handleLoadMore} disabled={loadingMore}
                className="border border-line rounded-xl2 px-5 py-2.5 text-sm text-muted hover:text-ink disabled:opacity-50">
                {loadingMore ? 'Loading…' : 'Load more'}
              </button>
            </div>
          )}
        </>
      )}
    </AppShell>
  );
}
